import { db } from "@/db";
import { faqs as ft } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { PageHero } from "@/components/SiteChrome";
import { ChevronDown } from "lucide-react";
import Link from "next/link";
export const dynamic="force-dynamic";
export const metadata={ title:"الأسئلة الشائعة | عبود لتحميل الفيديوهات" };
export default async function Page(){
  await ensureSeeded(); let rows:any[]=[]; try{ rows=(await db.select().from(ft).orderBy(ft.sortOrder)).filter(f=>f.published); }catch{}
  return <div><PageHero badge="مركز المساعدة" title="الأسئلة الشائعة" desc="إجابات صادقة وواضحة عن التنزيل، الخصوصية، المنصات، وربط الخدمات الخارجية."/>
    <div className="max-w-4xl mx-auto px-4 py-12"><div className="space-y-3">{rows.map((f:any)=>(<details key={f.id} className="group bg-white border rounded-2xl px-6 py-5"><summary className="font-black text-[#071633] cursor-pointer flex justify-between gap-3 list-none">{f.question}<ChevronDown className="w-5 h-5 text-sky-500 group-open:rotate-180 transition shrink-0"/></summary><p className="text-slate-600 leading-8 mt-3 text-[15px]">{f.answer}</p></details>))}</div>
    <div className="bg-sky-50 border border-sky-100 rounded-3xl p-6 text-center mt-8"><p className="font-black text-[#071633]">لم تجد إجابتك؟</p><Link href="/contact" className="grad-btn text-white font-black px-6 py-3 rounded-full inline-block mt-3">تواصل معنا</Link></div></div></div>;
}
