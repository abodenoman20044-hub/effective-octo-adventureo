"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Lock, Download } from "lucide-react";
export default function Page(){
  const [password,setPassword]=useState(""); const [msg,setMsg]=useState(""); const [loading,setLoading]=useState(false); const router=useRouter();
  async function submit(e:React.FormEvent){ e.preventDefault(); setLoading(true);
    const r=await fetch("/api/admin/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password})}); const j=await r.json();
    setLoading(false); if(j.ok) router.push("/admin"); else setMsg(j.message||"فشل تسجيل الدخول"); }
  return <div className="min-h-screen hero-bg grid place-items-center px-4"><form onSubmit={submit} className="bg-white rounded-[24px] p-8 w-full max-w-md shadow-2xl">
    <span className="w-14 h-14 rounded-2xl grad-btn grid place-items-center text-white mx-auto"><Download className="w-7 h-7"/></span>
    <h1 className="font-black text-2xl text-center text-[#071633] mt-4">لوحة إدارة عبود</h1><p className="text-sm text-slate-500 text-center mt-2 leading-6">هذه المنطقة لصاحب الموقع فقط. كلمة المرور من متغير البيئة <span dir="ltr" className="font-bold">ADMIN_PASSWORD</span> على الخادم.</p>
    <label className="text-sm font-bold block mt-6">كلمة المرور</label>
    <div className="relative mt-1.5"><Lock className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full border-2 border-slate-200 rounded-xl py-3 pr-10 pl-3 bg-slate-50" placeholder="••••••••"/></div>
    {msg&&<p className="bg-red-50 border border-red-200 text-red-700 text-sm font-bold rounded-xl px-4 py-3 mt-4">{msg}</p>}
    <button disabled={loading} className="grad-btn text-white font-black w-full py-3.5 rounded-xl mt-5 disabled:opacity-60">{loading?"جارٍ التحقق…":"دخول لوحة الإدارة"}</button>
    <p className="text-[11px] text-amber-700 bg-amber-50 border border-amber-100 rounded-xl px-3 py-2 mt-4 leading-5">تنبيه تشغيل: إذا لم تضبط ADMIN_PASSWORD بعد، توجد قيمة افتراضية مؤقتة في الكود لأول تشغيل — غيّرها فورًا من إعدادات بيئة الاستضافة وأعد النشر. حدّ محاولات الدخول: 8/دقيقة.</p>
    <a href="/" className="block text-center text-sm font-bold text-sky-600 mt-4">← العودة للموقع</a>
  </form></div>;
}
