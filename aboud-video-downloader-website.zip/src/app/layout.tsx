import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Header, Footer } from "@/components/SiteChrome";

export const metadata: Metadata = {
  title: "عبود لتحميل الفيديوهات | Aboud Video Downloader",
  description: "افحص روابط فيديو TikTok وYouTube وInstagram وX وVimeo وغيرها، احصل على معاينة فورية ومعلومات الفيديو مجانًا وبأمان.",
  keywords: ["تحميل فيديو","فحص رابط فيديو","TikTok","YouTube","عبود"],
  openGraph:{ title:"عبود لتحميل الفيديوهات", description:"حمّل فيديوهاتك المفضلة بسهولة — فحص ومعاينة فورية", type:"website", locale:"ar_EG" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="antialiased min-h-screen flex flex-col">
        <Header/>
        <main className="flex-1">{children}</main>
        <Footer/>
      </body>
    </html>
  );
}
