import Link from "next/link";
import { PageHero, AdSlot } from "@/components/SiteChrome";
import { Copy, Link2, Eye, AlertTriangle, Smartphone, Monitor } from "lucide-react";
export const metadata={ title:"طريقة الاستخدام | عبود لتحميل الفيديوهات" };
export default function Page(){
  return <div><PageHero badge="دليل الاستخدام" title="طريقة الاستخدام في 3 خطوات" desc="شرح عملي لنسخ الرابط من كل تطبيق، وفحصه، وفهم النتيجة — سواء ظهرت معاينة أو رسالة توضيحية."/>
    <div className="max-w-5xl mx-auto px-4 py-12 space-y-8">
      {[
        {icon:Copy,n:"الخطوة 1",t:"انسخ رابط الفيديو من التطبيق الأصلي",items:["TikTok: افتح الفيديو ← مشاركة ← نسخ الرابط","YouTube: مشاركة ← نسخ الرابط (أو انسخ من شريط العنوان)","Instagram: افتح الريل/الفيديو ← أيقونة المشاركة ← نسخ الرابط","X: أيقونة المشاركة أسفل المنشور ← نسخ الرابط","Facebook / Snapchat / Pinterest / Vimeo / Reddit: مشاركة ← نسخ الرابط","تأكد أن الحساب والفيديو عامّان؛ المحتوى الخاص لا يمكن فحصه ولا يجب تجاوز حمايته"]},
        {icon:Link2,n:"الخطوة 2",t:"الصق الرابط واضغط «فحص الرابط»",items:["ارجع إلى الصفحة الرئيسية والصق الرابط في المربع الكبير (زر لصق جاهز)","اترك اختيار المنصة على «اكتشاف تلقائي» — سنتعرف على المنصة من النطاق","اضغط فحص الرابط وانتظر مؤشر التحميل (عادة 1-3 ثوانٍ)","نظامنا يتحقق: صيغة الرابط، HTTPS، النطاق ضمن قائمة مسموحة، المنصة مفعّلة، وحدّ الطلبات"]},
        {icon:Eye,n:"الخطوة 3",t:"افهم النتيجة وتصرّف بشكل صحيح",items:["إذا ظهرت معاينة: سترى الصورة المصغرة والعنوان واسم صاحب الفيديو من مصدر oEmbed الرسمي","إذا ظهرت أزرار تنزيل: تعني أن مزودًا مرخصًا مرتبطًا بالخادم أرجع روابط حقيقية لهذا الفيديو بالفعل","إذا لم تظهر أزرار تنزيل: هذا مقصود وصادق — المنصة لا تسمح بذلك خارجيًا. استخدم زر «فتح الفيديو في المنصة الأصلية» حيث قد يتيح صاحب المحتوى الحفظ","لا تنزّل محتوى لا تملكه أو ليس لديك إذن باستخدامه"]},
      ].map((s,i)=>(<section key={i} className="bg-white rounded-[24px] border p-6 md:p-8"><div className="flex items-center gap-3"><span className="w-12 h-12 rounded-2xl grad-btn grid place-items-center text-white"><s.icon className="w-6 h-6"/></span><div><p className="text-xs font-black text-sky-600">{s.n}</p><h2 className="font-black text-xl text-[#071633]">{s.t}</h2></div></div><ul className="mt-5 space-y-2.5">{s.items.map((it,j)=>(<li key={j} className="flex gap-2 text-slate-600 leading-7 text-[15px]"><span className="w-5 h-5 rounded-full bg-sky-100 text-sky-700 grid place-items-center text-[11px] font-black shrink-0 mt-1">{j+1}</span>{it}</li>))}</ul></section>))}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-sky-50 border border-sky-100 rounded-3xl p-6"><Smartphone className="w-7 h-7 text-sky-600"/><h3 className="font-black mt-3 text-[#071633]">على الهاتف (iPhone / Android)</h3><p className="text-sm text-slate-600 leading-7 mt-2">الموقع متجاوب بالكامل. انسخ الرابط من التطبيق، بدّل إلى المتصفح، الصقه، وافحص. زر «لصق» يقرأ الحافظة بإذنك فقط.</p></div>
        <div className="bg-amber-50 border border-amber-100 rounded-3xl p-6"><AlertTriangle className="w-7 h-7 text-amber-600"/><h3 className="font-black mt-3 text-[#071633]">أخطاء شائعة</h3><p className="text-sm text-slate-600 leading-7 mt-2">رابط ناقص، رابط منصة غير مدعومة، فيديو خاص/محذوف، أو تجاوز حد 20 فحصًا في الدقيقة. ستظهر لك رسالة عربية واضحة في كل حالة.</p></div>
      </div>
      <AdSlot/>
      <div className="text-center"><Link href="/#checker" className="grad-btn text-white font-black px-8 py-3.5 rounded-full inline-block glow">ابدأ فحص أول رابط الآن</Link></div>
    </div></div>;
}
