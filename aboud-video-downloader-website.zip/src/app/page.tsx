import Link from "next/link";
import { db } from "@/db";
import { platforms as platformsTable, faqs as faqsTable, siteSettings } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import Checker from "@/components/Checker";
import { AdSlot } from "@/components/SiteChrome";
import { ShieldCheck, Zap, Smartphone, MousePointerClick, Link2, Eye, Download, ChevronDown, CheckCircle2, Globe, Lock, Sparkles, Play } from "lucide-react";

export const dynamic = "force-dynamic";

async function getData(){
  await ensureSeeded();
  try{
    const [p,f,s]=await Promise.all([db.select().from(platformsTable).orderBy(platformsTable.sortOrder), db.select().from(faqsTable).orderBy(faqsTable.sortOrder), db.select().from(siteSettings)]);
    return { platforms:p, faqs:f.filter(x=>x.published).slice(0,6), announcement: s.find(x=>x.key==="announcement")?.value||"" };
  }catch{ return { platforms:[], faqs:[], announcement:"" }; }
}

export default async function Home(){
  const { platforms, faqs, announcement } = await getData();
  return (
    <div>
      {/* HERO */}
      <section className="hero-bg text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 pt-12 pb-16 md:pt-16 md:pb-24 grid lg:grid-cols-[1fr_520px] gap-10 items-start">
          <div className="pt-2">
            <span className="inline-flex items-center gap-2 bg-white/10 border border-white/15 rounded-full px-4 py-1.5 text-xs font-bold text-sky-200"><Sparkles className="w-3.5 h-3.5"/> {announcement || "فحص ومعاينة روابط الفيديو مجانًا"}</span>
            <h1 className="text-4xl md:text-6xl font-black leading-[1.15] mt-6">حمّل فيديوهاتك<br/><span className="grad-text">المفضلة بسهولة</span></h1>
            <p className="text-slate-300 leading-8 mt-5 max-w-xl">الصق رابط أي فيديو من TikTok أو YouTube أو Instagram أو X أو Vimeo وغيرها، وسنستخرج لك رابطًا مباشرًا للتحميل بجودات MP4 عبر محرك yt-dlp على خادمنا — انسخه، شاركه، أو الصقه في مدير التحميل — بدون تسجيل وبدون أزرار وهمية.</p>
            <div className="grid grid-cols-3 gap-3 mt-8 max-w-lg">
              {[{icon:ShieldCheck,t:"آمن ومحمي",d:"SSRF + تحقق نطاقات"},{icon:Zap,t:"تحميل مباشر حقيقي",d:"yt-dlp على الخادم"},{icon:Smartphone,t:"يعمل على الهاتف",d:"iPhone و Android"}].map((x,i)=>(<div key={i} className="bg-white/[.07] border border-white/10 rounded-2xl p-3 text-center"><x.icon className="w-5 h-5 mx-auto text-sky-400"/><p className="font-black text-[13px] mt-2">{x.t}</p><p className="text-[11px] text-slate-400 mt-0.5">{x.d}</p></div>))}
            </div>
            <div className="flex items-center gap-4 mt-7 text-xs text-slate-300"><span className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4 text-emerald-400"/> {platforms.filter(p=>p.enabled).length} منصة مفعّلة</span><span className="flex items-center gap-1"><Lock className="w-4 h-4 text-sky-400"/> لا نخزن رابطك الكامل</span><span className="hidden sm:flex items-center gap-1"><Globe className="w-4 h-4 text-sky-400"/> عربي بالكامل RTL</span></div>
            <div className="mt-8 hidden lg:block"><AdSlot label="مساحة إعلانية — أسفل العنوان (لا تحجب الفاحص)"/></div>
          </div>
          <Checker platforms={platforms as any}/>
        </div>
      </section>

      {/* PLATFORMS */}
      <section className="max-w-7xl mx-auto px-4 py-14">
        <div className="text-center"><span className="text-xs font-black text-sky-600 bg-sky-50 border border-sky-100 rounded-full px-4 py-1.5">المنصات المدعومة</span><h2 className="text-2xl md:text-4xl font-black text-[#071633] mt-4">نتعامل مع روابط أكبر المنصات</h2><p className="text-slate-500 mt-3 max-w-2xl mx-auto leading-7">لكل منصة طريقة تكامل مختلفة حسب ما تسمح به رسميًا. نوضح بصدق مستوى الدعم لكل منصة:</p></div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-9">
          {platforms.map(p=>(
            <div key={p.id} className={`bg-white rounded-3xl border p-5 card-hover ${p.enabled?"border-slate-100":"border-slate-100 opacity-60"}`}>
              <div className="flex items-start justify-between"><span className="w-12 h-12 rounded-2xl grid place-items-center text-white font-black" style={{background:p.color}}>{p.nameEn.slice(0,2).toUpperCase()}</span><span className={`text-[10px] font-black px-2 py-1 rounded-full ${p.enabled?"bg-emerald-50 text-emerald-700":"bg-red-50 text-red-600"}`}>{p.enabled?"مفعّلة":"معطّلة"}</span></div>
              <h3 className="font-black text-[#071633] mt-3">{p.nameAr}</h3><p className="text-[11px] text-slate-400 font-bold" dir="ltr">{p.nameEn}</p>
              <span className={`inline-block mt-2 text-[10px] font-bold px-2 py-1 rounded-full ${p.oembedSupported?"bg-sky-50 text-sky-700":"bg-amber-50 text-amber-700"}`}>{p.oembedSupported?"معاينة oEmbed رسمية":"تحقق + فتح في الأصل"}</span>
              <p className="text-xs text-slate-500 leading-5 mt-2 line-clamp-2">{p.description}</p>
            </div>
          ))}
        </div>
        <div className="text-center mt-6"><Link href="/platforms" className="inline-flex items-center gap-1 font-black text-sky-600 hover:text-sky-700">عرض تفاصيل كل منصة وطريقة تكاملها ←</Link></div>
      </section>

      {/* HOW */}
      <section className="bg-[#071633] text-white py-14">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center"><h2 className="text-2xl md:text-4xl font-black">طريقة الاستخدام في <span className="grad-text">3 خطوات</span></h2><p className="text-slate-300 mt-3">أقل من 10 ثوانٍ من نسخ الرابط حتى المعاينة</p></div>
          <div className="grid md:grid-cols-3 gap-5 mt-10">
            {[{n:"01",icon:MousePointerClick,t:"انسخ رابط الفيديو",d:"افتح التطبيق الأصلي (TikTok / YouTube…) واضغط مشاركة ثم نسخ الرابط. تأكد أنه فيديو عام وليس خاصًا."},{n:"02",icon:Link2,t:"الصقه واضغط فحص الرابط",d:"الصق الرابط في الفاحص بالأعلى. نكتشف المنصة تلقائيًا، نتحقق من أمان الرابط ونطابقه مع النطاقات المسموحة فقط."},{n:"03",icon:Eye,t:"شاهد المعاينة وافتح الأصل",d:"تظهر لك الصورة والعنوان وصاحب الفيديو من المصدر الرسمي. إذا كان التنزيل المباشر مرخصًا ومتاحًا ستظهر أزراره الحقيقية هنا، وإلا زر فتح المنصة الأصلية."}].map((s,i)=>(
              <div key={i} className="bg-white/[.06] border border-white/10 rounded-[24px] p-6 relative overflow-hidden"><span className="absolute -top-2 left-4 text-6xl font-black text-white/[.07]">{s.n}</span><s.icon className="w-8 h-8 text-sky-400"/><h3 className="font-black text-lg mt-4">{s.t}</h3><p className="text-sm text-slate-300 leading-7 mt-2">{s.d}</p></div>
            ))}
          </div>
          <div className="text-center mt-8"><Link href="/how-to-use" className="bg-white text-[#071633] font-black px-6 py-3 rounded-full inline-block hover:bg-sky-50">شرح مفصل بالصور النصية لكل منصة</Link></div>
        </div>
      </section>

      {/* HONESTY / FEATURES */}
      <section className="max-w-7xl mx-auto px-4 py-14 grid lg:grid-cols-2 gap-8 items-center">
        <div><span className="text-xs font-black text-sky-600 bg-sky-50 border border-sky-100 rounded-full px-4 py-1.5">لماذا تثق بعبود؟</span><h2 className="text-2xl md:text-4xl font-black text-[#071633] mt-4 leading-snug">لا أزرار وهمية.<br/>لا وعود كاذبة.</h2><p className="text-slate-600 leading-8 mt-4">كثير من مواقع التنزيل تعرض أزرارًا مضللة. نحن مختلفون: إذا لم يكن التنزيل المباشر مسموحًا أو مرخصًا لمنصة معينة، نقول لك ذلك بوضوح ونريك المعاينة الرسمية وطريق الوصول الأصلي. وعند ربط مزود مرخص من الخادم، تظهر خيارات التنزيل الحقيقية فقط.</p>
          <ul className="space-y-3 mt-6">{["معاينة من نقاط oEmbed الرسمية فقط (YouTube / TikTok / Vimeo / X / Reddit / Dailymotion)","حماية SSRF وحظر النطاقات الداخلية وحدّ لعدد الطلبات","لا نخزن نص الرابط الكامل — إحصاءات مجهولة فقط","جاهز لربط مزود تنزيل مرخص عبر DOWNLOADER_API_URL دون كشف المفتاح في المتصفح"].map((t,i)=>(<li key={i} className="flex gap-2 text-sm font-bold text-slate-700"><CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0"/>{t}</li>))}</ul></div>
        <div className="space-y-4"><div className="bg-[#071633] text-white rounded-[24px] p-6"><p className="flex items-center gap-2 font-black"><Play className="text-sky-400"/> ما الذي يعمل الآن فعليًا؟</p><ul className="text-sm text-slate-300 leading-7 mt-3 space-y-1"><li>✓ فحص وتحقق واكتشاف منصة لـ 11 منصة</li><li>✓ تحميل مباشر حقيقي عبر yt-dlp: YouTube، TikTok، Vimeo، X، Reddit، Dailymotion، Dailymotion وغيرها للفيديوهات العامة</li><li>✓ محاولة استخراج مباشر: Instagram، Facebook، Pinterest، Twitch (قد تقيدها المنصة فتظهر رسالة صادقة)</li><li>✓ روابط موقّعة تُبث عبر /api/download-file وصلاحيتها 15 دقيقة</li><li>ℹ مستودع VidFetch تمت مراجعته وربط رابطه — ملفاته لا تحتوي كود خادم تحميل، والمحرك الفعلي هنا هو yt-dlp</li></ul></div><AdSlot/></div>
      </section>

      {/* FAQ preview */}
      <section className="bg-white border-y py-14"><div className="max-w-4xl mx-auto px-4"><h2 className="text-2xl md:text-3xl font-black text-center text-[#071633]">الأسئلة الشائعة</h2><div className="mt-8 space-y-3">{faqs.map(f=>(<details key={f.id} className="group border rounded-2xl px-5 py-4 bg-slate-50/60"><summary className="font-black text-[#071633] cursor-pointer flex items-center justify-between gap-2 list-none">{f.question}<ChevronDown className="w-5 h-5 text-sky-500 group-open:rotate-180 transition shrink-0"/></summary><p className="text-sm text-slate-600 leading-7 mt-3">{f.answer}</p></details>))}</div><div className="text-center mt-6"><Link href="/faq" className="font-black text-sky-600">جميع الأسئلة الشائعة ←</Link></div></div></section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 py-12"><div className="hero-bg rounded-[28px] text-white text-center px-6 py-12"><Download className="w-10 h-10 mx-auto text-sky-400"/><h2 className="text-2xl md:text-3xl font-black mt-4">جاهز تجرب؟ الصق أول رابط الآن</h2><p className="text-slate-300 mt-2">مجاني، سريع، وبدون إنشاء حساب</p><a href="#checker" className="grad-btn glow inline-block mt-6 text-white font-black px-8 py-3.5 rounded-full">العودة إلى الفاحص ↑</a></div></section>
    </div>
  );
}
