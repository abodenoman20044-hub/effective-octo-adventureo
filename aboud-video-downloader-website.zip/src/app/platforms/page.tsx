import { db } from "@/db";
import { platforms as pt } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { PageHero, AdSlot } from "@/components/SiteChrome";
import Link from "next/link";
export const dynamic="force-dynamic";
export const metadata={ title:"المنصات المدعومة | عبود لتحميل الفيديوهات" };
export default async function Page(){
  await ensureSeeded(); let rows:any[]=[]; try{ rows=await db.select().from(pt).orderBy(pt.sortOrder); }catch{}
  return <div><PageHero badge="شفافية كاملة" title="المنصات المدعومة وطريقة تكامل كل منها" desc="لا ندّعي دعمًا كاملًا لجميع المنصات. هذا الجدول يوضح بصدق: ما الذي يعمل الآن، وما الذي يحتاج رمز وصول رسميًا، وسبب ذلك."/>
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
        {rows.map((p:any)=>(<article key={p.id} className="bg-white border rounded-[24px] p-6 card-hover">
          <div className="flex items-center justify-between"><span className="w-14 h-14 rounded-2xl grid place-items-center text-white font-black text-lg" style={{background:p.color}}>{p.nameEn.slice(0,2).toUpperCase()}</span><span className={`text-[11px] font-black px-3 py-1 rounded-full ${p.enabled?"bg-emerald-50 text-emerald-700":"bg-red-50 text-red-600"}`}>{p.enabled?"● مفعّلة":"● معطّلة من الإدارة"}</span></div>
          <h2 className="font-black text-xl text-[#071633] mt-4">{p.nameAr} <span className="text-sm text-slate-400" dir="ltr">{p.nameEn}</span></h2>
          <div className="flex flex-wrap gap-1.5 mt-3">{(p.domains||[]).map((d:string)=>(<span key={d} dir="ltr" className="text-[10px] bg-slate-100 rounded px-2 py-0.5 font-bold text-slate-600">{d}</span>))}</div>
          <p className="text-sm text-slate-600 leading-7 mt-3">{p.description}</p>
          <div className="mt-4 pt-4 border-t flex items-center justify-between"><span className={`text-[11px] font-black px-2.5 py-1 rounded-full ${p.oembedSupported?"bg-sky-50 text-sky-700":"bg-amber-50 text-amber-700"}`}>{p.oembedSupported?"✓ معاينة oEmbed رسمية":"تحقق + فتح أصلي فقط"}</span><Link href="/#checker" className="text-sm font-black text-sky-600">جرّب فحصًا ←</Link></div>
        </article>))}
      </div>
      <div className="bg-[#071633] text-white rounded-[24px] p-7 mt-10"><h3 className="font-black text-xl">كيف تُضاف منصة جديدة مستقبلًا؟</h3><p className="text-slate-300 leading-8 mt-3 text-[15px]">النظام مبني على سجل منصات (Registry) في <span dir="ltr" className="text-sky-300">src/lib/platforms.ts</span> + جدول في قاعدة البيانات. لإضافة منصة: أضف تعريفها (النطاقات، نقطة oEmbed إن وجدت، طريقة الدعم)، فعّلها من لوحة الإدارة، وانشر. لا حاجة لإعادة بناء الموقع. أي منصة تتطلب Token رسميًا (Meta/Instagram/Facebook) تُضاف مفاتيحها كمتغيرات بيئة خادم فقط.</p></div>
      <div className="mt-6"><AdSlot/></div>
    </div></div>;
}
