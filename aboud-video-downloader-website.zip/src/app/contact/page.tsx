"use client";
import { useState } from "react";
import { PageHero } from "@/components/SiteChrome";
import { Send, CheckCircle2, Mail, ShieldCheck } from "lucide-react";
export default function Page(){
  const [form,setForm]=useState({name:"",email:"",subject:"",message:""});
  const [msg,setMsg]=useState(""); const [ok,setOk]=useState(false); const [loading,setLoading]=useState(false);
  async function submit(e:React.FormEvent){ e.preventDefault(); setLoading(true); setMsg("");
    try{ const r=await fetch("/api/contact",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); const j=await r.json(); setMsg(j.message); setOk(j.ok); if(j.ok) setForm({name:"",email:"",subject:"",message:""}); }catch{ setMsg("تعذر الإرسال، حاول مجددًا."); } finally{ setLoading(false);} }
  return <div><PageHero badge="نرد خلال أيام العمل" title="اتصل بنا" desc="سؤال، بلاغ عن رابط لا يعمل، طلب إزالة محتوى، أو اقتراح منصة جديدة — راسلنا وسيصل طلبك إلى لوحة الإدارة مباشرة."/>
    <div className="max-w-3xl mx-auto px-4 py-12">
      <form onSubmit={submit} className="bg-white border rounded-[24px] p-6 md:p-8 shadow-sm space-y-4">
        <div className="grid md:grid-cols-2 gap-4"><div><label className="text-sm font-bold">الاسم *</label><input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="w-full mt-1.5 border-2 border-slate-200 rounded-xl px-4 py-3 bg-slate-50" placeholder="اسمك"/></div><div><label className="text-sm font-bold">البريد الإلكتروني *</label><input required type="email" dir="ltr" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} className="w-full mt-1.5 border-2 border-slate-200 rounded-xl px-4 py-3 bg-slate-50 text-left" placeholder="you@email.com"/></div></div>
        <div><label className="text-sm font-bold">الموضوع</label><input value={form.subject} onChange={e=>setForm({...form,subject:e.target.value})} className="w-full mt-1.5 border-2 border-slate-200 rounded-xl px-4 py-3 bg-slate-50" placeholder="مثال: رابط TikTok لا يعمل"/></div>
        <div><label className="text-sm font-bold">رسالتك *</label><textarea required rows={6} value={form.message} onChange={e=>setForm({...form,message:e.target.value})} className="w-full mt-1.5 border-2 border-slate-200 rounded-xl px-4 py-3 bg-slate-50" placeholder="اكتب تفاصيل طلبك. لا ترسل كلمات مرور أو بيانات حساسة."/></div>
        {msg && <p className={`rounded-xl px-4 py-3 text-sm font-bold flex items-center gap-2 ${ok?"bg-emerald-50 text-emerald-700 border border-emerald-200":"bg-red-50 text-red-700 border border-red-200"}`}>{ok&&<CheckCircle2 className="w-4 h-4"/>}{msg}</p>}
        <button disabled={loading} className="grad-btn glow text-white font-black w-full py-3.5 rounded-xl flex items-center justify-center gap-2 disabled:opacity-60"><Send className="w-4 h-4"/> {loading?"جارٍ الإرسال…":"إرسال الرسالة"}</button>
        <p className="text-[11px] text-slate-400 text-center flex items-center justify-center gap-1"><ShieldCheck className="w-3.5 h-3.5"/> تُحفظ الرسالة في قاعدة البيانات لعرضها في لوحة الإدارة فقط. حدّ الإرسال: 5 رسائل/دقيقة.</p>
      </form>
      <div className="grid md:grid-cols-2 gap-4 mt-5"><div className="bg-white border rounded-2xl p-5"><Mail className="text-sky-600"/><p className="font-black mt-2">طلبات حقوق النشر</p><p className="text-sm text-slate-500 leading-6 mt-1">استخدم نموذج التواصل مع اختيار موضوع «حقوق ملكية» وأرفق رابط المحتوى وإثبات الملكية. راجع صفحة حقوق الملكية الفكرية.</p></div><div className="bg-white border rounded-2xl p-5"><ShieldCheck className="text-sky-600"/><p className="font-black mt-2">الإبلاغ عن إساءة</p><p className="text-sm text-slate-500 leading-6 mt-1">إذا لاحظت استخدامًا مسيئًا أو رابطًا خبيثًا، أبلغنا فورًا وسنراجع سجلات الأخطاء (غير الشخصية) ونتخذ إجراء.</p></div></div>
    </div></div>;
}
