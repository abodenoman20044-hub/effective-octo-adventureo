import { NextResponse } from "next/server";
import { db } from "@/db";
import { platforms, linkChecks } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";
import { detectPlatform } from "@/lib/platforms";
import { validateUserUrl, rateLimit, getClientIp } from "@/lib/security";
import { extractDownloadOptions } from "@/lib/downloader";

export const maxDuration = 60;

// POST /api/direct-link  { url }  ->  { ok, directLink: { downloadUrl, directUrl, label, quality, ext, expiresInMinutes }, platform }
// Purpose: generate ONLY the direct download link (رابط مباشر للتحميل) without the full check UI payload.
export async function POST(req: Request) {
  await ensureSeeded();
  if (!rateLimit(`direct:${getClientIp(req)}`, 12, 60_000)) {
    return NextResponse.json({ ok: false, code: "RATE_LIMITED", message: "طلبات كثيرة جدًا. انتظر دقيقة." }, { status: 429 });
  }
  try {
    const body = await req.json().catch(() => ({}));
    const v = validateUserUrl(String(body.url || ""));
    if (!v.ok) return NextResponse.json({ ok: false, code: "INVALID_URL", message: v.error });
    const url = v.url;
    const def = detectPlatform(url.hostname);
    if (!def) return NextResponse.json({ ok: false, code: "UNSUPPORTED", message: `النطاق ${url.hostname} غير مدعوم حاليًا.` });
    try {
      const rows = await db.select().from(platforms).where(eq(platforms.key, def.key));
      if (rows[0] && !rows[0].enabled) return NextResponse.json({ ok: false, code: "DISABLED", message: `منصة ${def.nameAr} معطّلة مؤقتًا من الإدارة.` });
    } catch {}
    if (process.env.ENABLE_DIRECT_DOWNLOAD === "false") {
      return NextResponse.json({ ok: false, code: "DISABLED", message: "التحميل المباشر معطّل من إعدادات الخادم حاليًا." });
    }
    const ex = await extractDownloadOptions(url.toString(), def.key, def.nameEn);
    await db.insert(linkChecks).values({ platformKey: def.key, domain: url.hostname, success: ex.ok, status: ex.ok ? "direct_link_ready" : "direct_link_failed", hasPreview: false }).catch(() => {});
    if (!ex.ok || ex.options.length === 0) {
      return NextResponse.json({ ok: false, code: "NO_DIRECT_LINK", message: ex.error || "لم يتم استخراج رابط مباشر لهذا الفيديو.", platform: { key: def.key, nameAr: def.nameAr, nameEn: def.nameEn } });
    }
    const best =
      ex.options.find((o: any) => o.kind === "merged" && o.height === 720) ||
      ex.options.find((o: any) => o.kind === "merged") ||
      ex.options.find((o: any) => o.kind === "av") ||
      ex.options[0];
    return NextResponse.json({
      ok: true,
      platform: { key: def.key, nameAr: def.nameAr, nameEn: def.nameEn },
      title: ex.title || "",
      directLink: {
        label: best.label, quality: best.quality || "", ext: best.ext || "mp4", kind: best.kind,
        downloadUrl: best.downloadUrl, // proxied direct download via Aboud (use this one — reliable + correct filename)
        directUrl: best.directUrl || null, // raw source CDN link when single-file format
        directType: best.directType || "merged_proxy",
        filesizeText: best.filesizeText || "",
        expiresInMinutes: best.expiresInMinutes || 15,
      },
      allOptions: ex.options.map((o: any) => ({ label: o.label, quality: o.quality, ext: o.ext, kind: o.kind, downloadUrl: o.downloadUrl, directUrl: o.directUrl || null, filesizeText: o.filesizeText || "" })),
      usage: "افتح downloadUrl في المتصفح أو الصقه في مدير تحميل (IDM) خلال 15 دقيقة. إذا انتهت صلاحيته أعد توليد الرابط.",
    });
  } catch (e: any) {
    return NextResponse.json({ ok: false, code: "SERVER_ERROR", message: "حدث خطأ أثناء توليد الرابط المباشر. حاول مجددًا." }, { status: 500 });
  }
}
