import { NextResponse } from "next/server";
import { db } from "@/db";
import { faqs } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
export async function GET(){ await ensureSeeded(); try{ const rows=await db.select().from(faqs).orderBy(faqs.sortOrder); return NextResponse.json({ faqs: rows.filter(f=>f.published) }); }catch{ return NextResponse.json({ faqs: [] }); } }
