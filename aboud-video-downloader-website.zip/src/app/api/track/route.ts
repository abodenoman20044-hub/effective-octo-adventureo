import { NextResponse } from "next/server";
import { db } from "@/db";
import { pageViews } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
export async function POST(req: Request){ await ensureSeeded(); const b=await req.json().catch(()=>({})); const path=String(b.path||"/").slice(0,300); await db.insert(pageViews).values({path}).catch(()=>{}); return NextResponse.json({ok:true}); }
