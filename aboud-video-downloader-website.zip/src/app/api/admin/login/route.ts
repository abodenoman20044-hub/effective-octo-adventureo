import { NextResponse } from "next/server";
import { adminPassword } from "@/lib/seed";
import { rateLimit, getClientIp } from "@/lib/security";
export async function POST(req: Request){
  if(!rateLimit(`login:${getClientIp(req)}`,8,60_000)) return NextResponse.json({ok:false,message:"محاولات كثيرة. انتظر دقيقة."},{status:429});
  const b=await req.json().catch(()=>({}));
  if(String(b.password||"") !== adminPassword()) return NextResponse.json({ok:false,message:"كلمة المرور غير صحيحة."},{status:401});
  const token = process.env.ADMIN_SESSION_TOKEN || "aboud-admin-session-2026";
  const res = NextResponse.json({ok:true});
  res.cookies.set("aboud_admin", token, { httpOnly:true, sameSite:"lax", path:"/", maxAge:60*60*8 });
  return res;
}
