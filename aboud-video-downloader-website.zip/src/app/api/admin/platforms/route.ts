import { NextResponse } from "next/server";
import { db } from "@/db";
import { platforms } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isAdmin } from "@/lib/seed";
export async function PATCH(req: Request){
  if(!isAdmin(req)) return NextResponse.json({ok:false},{status:401});
  const b=await req.json().catch(()=>({}));
  const id=Number(b.id); if(!id) return NextResponse.json({ok:false,message:"id required"},{status:400});
  const patch:any={};
  if(typeof b.enabled==="boolean") patch.enabled=b.enabled;
  if(typeof b.description==="string") patch.description=b.description.slice(0,1000);
  if(typeof b.downloadMode==="string") patch.downloadMode=b.downloadMode;
  await db.update(platforms).set(patch).where(eq(platforms.id,id));
  return NextResponse.json({ok:true});
}
