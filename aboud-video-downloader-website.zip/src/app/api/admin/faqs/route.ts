import { NextResponse } from "next/server";
import { db } from "@/db";
import { faqs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isAdmin } from "@/lib/seed";
export async function POST(req: Request){
  if(!isAdmin(req)) return NextResponse.json({ok:false},{status:401});
  const b=await req.json().catch(()=>({}));
  if(b.action==="delete"){ await db.delete(faqs).where(eq(faqs.id,Number(b.id))); return NextResponse.json({ok:true}); }
  if(b.action==="update"){ await db.update(faqs).set({question:String(b.question||"").slice(0,500),answer:String(b.answer||"").slice(0,3000),published:!!b.published}).where(eq(faqs.id,Number(b.id))); return NextResponse.json({ok:true}); }
  const [row]=await db.insert(faqs).values({question:String(b.question||"").slice(0,500),answer:String(b.answer||"").slice(0,3000),sortOrder:Number(b.sortOrder||99),published:true}).returning();
  return NextResponse.json({ok:true,faq:row});
}
