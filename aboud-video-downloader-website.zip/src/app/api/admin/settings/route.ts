import { NextResponse } from "next/server";
import { db } from "@/db";
import { siteSettings, contactMessages } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isAdmin } from "@/lib/seed";
export async function POST(req: Request){
  if(!isAdmin(req)) return NextResponse.json({ok:false},{status:401});
  const b=await req.json().catch(()=>({}));
  if(b.type==="message_status"){ await db.update(contactMessages).set({status:String(b.status||"read")}).where(eq(contactMessages.id,Number(b.id))); return NextResponse.json({ok:true}); }
  const key=String(b.key||"announcement"); const value=String(b.value||"").slice(0,1000);
  const existing=await db.select().from(siteSettings).where(eq(siteSettings.key,key));
  if(existing.length) await db.update(siteSettings).set({value}).where(eq(siteSettings.key,key)); else await db.insert(siteSettings).values({key,value});
  return NextResponse.json({ok:true});
}
