import { NextResponse } from "next/server";
import { db } from "@/db";
import { platforms, faqs, contactMessages, linkChecks, errorLogs, pageViews, siteSettings } from "@/db/schema";
import { desc } from "drizzle-orm";
import { ensureSeeded, isAdmin } from "@/lib/seed";
export async function GET(req: Request){
  if(!isAdmin(req)) return NextResponse.json({ok:false,message:"غير مصرح"},{status:401});
  await ensureSeeded();
  const [plats, allFaqs, msgs, checks, errors, views, settings] = await Promise.all([
    db.select().from(platforms).orderBy(platforms.sortOrder),
    db.select().from(faqs).orderBy(faqs.sortOrder),
    db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt)).limit(50),
    db.select().from(linkChecks).orderBy(desc(linkChecks.createdAt)).limit(100),
    db.select().from(errorLogs).orderBy(desc(errorLogs.createdAt)).limit(50),
    db.select().from(pageViews),
    db.select().from(siteSettings),
  ]);
  const totalChecks = checks.length; // note: limited sample for recent; compute counts below via full selects would be heavy — use views length etc.
  const allChecks = await db.select().from(linkChecks);
  const byPlatform: Record<string, number> = {};
  allChecks.forEach(c=>{ byPlatform[c.platformKey]=(byPlatform[c.platformKey]||0)+1; });
  return NextResponse.json({
    ok:true,
    stats:{ totalViews: views.length, totalChecks: allChecks.length, successfulChecks: allChecks.filter(c=>c.success).length, failedChecks: allChecks.filter(c=>!c.success).length, totalMessages: msgs.length, newMessages: msgs.filter(m=>m.status==="new").length, totalErrors: errors.length, enabledPlatforms: plats.filter(p=>p.enabled).length, totalPlatforms: plats.length, byPlatform },
    platforms: plats, faqs: allFaqs, messages: msgs, recentChecks: checks.slice(0,30), errors, settings,
    envStatus:{ downloaderConfigured: process.env.ENABLE_DIRECT_DOWNLOAD !== "false", downloaderEngine: "yt-dlp via youtube-dl-exec", vidfetchRepo: "https://github.com/achir22hasan1999-crypto/VidFetch", adminPasswordSource: process.env.ADMIN_PASSWORD ? "ADMIN_PASSWORD env" : "قيمة افتراضية — غيّرها فورًا من متغير ADMIN_PASSWORD", database: "PostgreSQL عبر DATABASE_URL" }
  });
}
