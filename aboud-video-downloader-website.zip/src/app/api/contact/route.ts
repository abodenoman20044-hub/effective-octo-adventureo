import { NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { rateLimit, getClientIp } from "@/lib/security";
export async function POST(req: Request){
  await ensureSeeded();
  if(!rateLimit(`contact:${getClientIp(req)}`,5,60_000)) return NextResponse.json({ok:false,message:"طلبات كثيرة، انتظر دقيقة."},{status:429});
  const b=await req.json().catch(()=>({}));
  const name=String(b.name||"").trim(), email=String(b.email||"").trim(), subject=String(b.subject||"").trim(), message=String(b.message||"").trim();
  if(name.length<2||!email.includes("@")||message.length<5) return NextResponse.json({ok:false,message:"يرجى إدخال الاسم وبريد صحيح ورسالة لا تقل عن 5 أحرف."});
  await db.insert(contactMessages).values({name:name.slice(0,120),email:email.slice(0,200),subject:subject.slice(0,200),message:message.slice(0,3000)});
  return NextResponse.json({ok:true,message:"تم استلام رسالتك بنجاح. سنرد عليك على بريدك الإلكتروني في أقرب وقت."});
}
