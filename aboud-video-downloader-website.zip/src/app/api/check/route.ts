import { NextResponse } from "next/server";
import { db } from "@/db";
import { platforms, linkChecks, errorLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";
import { detectPlatform, PLATFORM_DEFS } from "@/lib/platforms";
import { validateUserUrl, rateLimit, getClientIp } from "@/lib/security";
import { extractDownloadOptions, VIDFETCH_REPO, VIDFETCH_AUDIT } from "@/lib/downloader";

export const maxDuration = 60;

export async function POST(req: Request) {
  await ensureSeeded();
  const ip = getClientIp(req);
  if (!rateLimit(`check:${ip}`, 20, 60_000)) {
    return NextResponse.json({ ok:false, code:"RATE_LIMITED", message:"طلبات كثيرة جدًا. انتظر دقيقة ثم حاول مجددًا لحماية الخدمة من إساءة الاستخدام." }, { status:429 });
  }
  try {
    const body = await req.json().catch(()=>({}));
    const raw = String(body.url || "");
    const v = validateUserUrl(raw);
    if (!v.ok) {
      await db.insert(linkChecks).values({ platformKey:"unknown", domain:"", success:false, status:"invalid", hasPreview:false }).catch(()=>{});
      return NextResponse.json({ ok:false, code:"INVALID_URL", message:v.error });
    }
    const url = v.url;
    const def = detectPlatform(url.hostname);
    if (!def) {
      await db.insert(linkChecks).values({ platformKey:"unknown", domain:url.hostname, success:false, status:"unsupported", hasPreview:false }).catch(()=>{});
      return NextResponse.json({ ok:false, code:"UNSUPPORTED", message:`النطاق ${url.hostname} غير مدعوم حاليًا. المنصات المدعومة: ${PLATFORM_DEFS.map(p=>p.nameAr).join("، ")}.`, domain:url.hostname });
    }
    // DB enabled check
    let dbPlatform: typeof platforms.$inferSelect | undefined;
    try { const rows = await db.select().from(platforms).where(eq(platforms.key, def.key)); dbPlatform = rows[0]; } catch {}
    const enabled = dbPlatform ? dbPlatform.enabled : true;
    if (!enabled) {
      await db.insert(linkChecks).values({ platformKey:def.key, domain:url.hostname, success:false, status:"disabled", hasPreview:false }).catch(()=>{});
      return NextResponse.json({ ok:false, code:"DISABLED", message:`منصة ${def.nameAr} معطّلة مؤقتًا من إدارة الموقع. جرّب لاحقًا أو افتح الفيديو في المنصة الأصلية.`, platform:{ key:def.key, nameAr:def.nameAr, nameEn:def.nameEn, color:def.color }, originalUrl:url.toString() });
    }

    // Try oEmbed (official endpoints only)
    let preview: any = null; let oembedError = "";
    if (def.oembed) {
      try {
        const endpoint = def.oembed(url.toString());
        const ctrl = new AbortController(); const t = setTimeout(()=>ctrl.abort(), 9000);
        const r = await fetch(endpoint, { signal:ctrl.signal, headers:{ "User-Agent":"AboudVideoDownloader/1.0 (+oEmbed)", "Accept":"application/json" } });
        clearTimeout(t);
        if (r.ok) {
          const j:any = await r.json();
          preview = {
            title: j.title || "", author: j.author_name || "", authorUrl: j.author_url || "",
            thumbnail: j.thumbnail_url || "", thumbnailWidth: j.thumbnail_width, thumbnailHeight: j.thumbnail_height,
            provider: j.provider_name || def.nameEn, type: j.type || "video",
            htmlAvailable: !!j.html,
          };
        } else { oembedError = `oEmbed returned ${r.status}`; }
      } catch (e:any) { oembedError = e?.name==="AbortError" ? "oEmbed timeout (9s)" : String(e?.message||e); }
    }

    // REAL direct download extraction via yt-dlp engine running on this server.
    // VidFetch repo was audited: it contains no downloader backend (see VIDFETCH_AUDIT), so this engine provides the actual functionality.
    let downloadOptions: any[] = []; let downloaderConfigured = true; let downloaderNote = "";
    let downloadEngine = "yt-dlp"; let extractError = ""; let extractedMeta: any = null;
    const directEnabled = process.env.ENABLE_DIRECT_DOWNLOAD !== "false";
    if (directEnabled) {
      const ex = await extractDownloadOptions(url.toString(), def.key, def.nameEn);
      downloadEngine = ex.engine; extractedMeta = ex;
      if (ex.ok && ex.options.length > 0) {
        downloadOptions = ex.options;
        downloaderNote = `تم استخراج ${ex.options.length} صيغة حقيقية من مصدر الفيديو عبر ${ex.engine}. روابط التحميل تُبث عبر خادم عبود وصلاحيتها 15 دقيقة — اختر صيغة (صوت+فيديو) للملف الكامل.`;
        if (!preview && (ex.title || ex.thumbnail)) {
          preview = { title: ex.title || "", author: ex.uploader || "", authorUrl: "", thumbnail: ex.thumbnail || "", provider: def.nameEn, type: "video", htmlAvailable: false };
        }
      } else { extractError = ex.error || "تعذر الاستخراج"; }
    }

    // Optional licensed provider as additional fallback (server-side only, never exposed to browser)
    const dlUrl = process.env.DOWNLOADER_API_URL; const dlKey = process.env.DOWNLOADER_API_KEY;
    if (downloadOptions.length === 0 && dlUrl && dlKey) {
      downloaderConfigured = true;
      try {
        const ctrl = new AbortController(); const t = setTimeout(()=>ctrl.abort(), 12000);
        const r = await fetch(dlUrl, { method:"POST", signal:ctrl.signal, headers:{ "Content-Type":"application/json", "Authorization":`Bearer ${dlKey}` }, body: JSON.stringify({ url:url.toString(), platform:def.key }) });
        clearTimeout(t);
        if (r.ok) {
          const j:any = await r.json();
          // Expect provider to return { formats: [{label, url, quality}] } — only show real returned links
          const formats = Array.isArray(j.formats) ? j.formats : Array.isArray(j.links) ? j.links : [];
          downloadOptions = formats.filter((f:any)=>f && f.url && typeof f.url==="string" && f.url.startsWith("https://")).map((f:any)=>({ label:f.label||f.quality||"تنزيل", quality:f.quality||"", url:f.url, downloadUrl:f.url, directUrl:f.url, directType:"provider_direct", ext:f.ext||"mp4", kind:"av", expiresInMinutes:15 })).slice(0,8);
          if (downloadOptions.length===0) downloaderNote = "المزود المرخص لم يُرجع روابط تنزيل لهذا الفيديو.";
        } else { downloaderNote = `مزود التنزيل المرخص أرجع حالة ${r.status}.`; }
      } catch (e:any) { downloaderNote = "تعذر الاتصال بمزود التنزيل المرخص حاليًا."; }
    }

    await db.insert(linkChecks).values({ platformKey:def.key, domain:url.hostname, success: downloadOptions.length>0 || !!preview, status: downloadOptions.length>0 ? "download_ready" : (preview ? "ok" : (oembedError ? "oembed_failed" : "checked")), hasPreview:!!preview }).catch(()=>{});
    if (oembedError && def.oembed) {
      await db.insert(errorLogs).values({ source:"oembed", message:oembedError.slice(0,500), platformKey:def.key }).catch(()=>{});
    }
    if (extractError) {
      await db.insert(errorLogs).values({ source:"ytdlp_extract", message:extractError.slice(0,500), platformKey:def.key }).catch(()=>{});
    }

    // === DIRECT LINK (رابط مباشر) — best single option, ready to copy/share/use in a download manager ===
    const bestDirect =
      downloadOptions.find((o:any)=>o.kind==="merged" && o.height===720) ||
      downloadOptions.find((o:any)=>o.kind==="merged") ||
      downloadOptions.find((o:any)=>o.kind==="av") ||
      downloadOptions[0] || null;
    const directLink = bestDirect ? {
      label: bestDirect.label, quality: bestDirect.quality || "", ext: bestDirect.ext || "mp4", kind: bestDirect.kind,
      // Proxied one-click download through Aboud (correct filename, headers handled, resumable)
      downloadUrl: bestDirect.downloadUrl || bestDirect.url,
      // Raw direct source link when the format is a single CDN file (null for server-merged formats)
      directUrl: bestDirect.directUrl || null,
      directType: bestDirect.directType || (bestDirect.directUrl ? "cdn_direct" : "merged_proxy"),
      filesizeText: bestDirect.filesizeText || "",
      expiresInMinutes: bestDirect.expiresInMinutes || 15,
      note: bestDirect.directUrl
        ? "هذا هو الرابط المباشر من مصدر المنصة نفسه. قد تنتهي صلاحيته خلال دقائق من المنصة، لذا زر «تحميل مباشر الآن» عبر عبود أكثر استقرارًا ويمنحك اسم ملف صحيحًا."
        : "الملف الكامل (صوت+فيديو) يُبنى على خادم عبود عند الضغط عبر هذا الرابط المباشر، لذلك لا يوجد رابط CDN واحد له — انسخ رابط عبود المباشر واستخدمه فورًا.",
    } : null;

    return NextResponse.json({
      ok:true,
      platform:{ key:def.key, nameAr:def.nameAr, nameEn:def.nameEn, color:def.color, downloadMode:"direct", oembedSupported:def.oembedSupported },
      originalUrl:url.toString(), domain:url.hostname,
      preview,
      previewAvailable: !!preview,
      previewNote: preview ? "تم جلب المعاينة من مصدر المنصة الرسمي/المحرك." : def.oembed ? "لم تُرجع المنصة معاينة عامة (قد يكون الفيديو خاصًا أو محذوفًا أو يتطلب تسجيل دخول). يمكنك فتحه في المنصة الأصلية." : "هذه المنصة لا توفر معاينة oEmbed عامة بدون رمز وصول رسمي. تحققنا من الرابط ويمكنك فتحه في المنصة الأصلية.",
      downloadOptions, directLink, downloaderConfigured, downloadEngine,
      extractedTitle: extractedMeta?.title || "", rawFormats: extractedMeta?.rawFormats || 0,
      vidfetchRepo: VIDFETCH_REPO, vidfetchAudit: VIDFETCH_AUDIT,
      downloadNote: downloadOptions.length>0 ? downloaderNote : `لم نتمكن من استخراج تحميل مباشر لهذا الرابط تحديدًا. السبب: ${extractError || downloaderNote || "غير معروف"}. هذا ليس زرًا وهميًا — جرّب رابطًا عامًا آخر أو افتح الفيديو في المنصة الأصلية. قد تفشل بعض فيديوهات YouTube/Instagram مؤقتًا بسبب حماية المنصة ضد الروبوتات من عناوين IP الخوادم.`,
      disclaimer:"باستخدام التحميل أنت تقر أنك تملك المحتوى أو لديك إذن صاحبه أو أنه مرخص للتنزيل. لا تستخدمه لانتهاك حقوق النشر أو شروط المنصة.",
    });
  } catch (e:any) {
    try { await db.insert(errorLogs).values({ source:"check_api", message:String(e?.message||e).slice(0,500), platformKey:"" }); } catch {}
    return NextResponse.json({ ok:false, code:"SERVER_ERROR", message:"حدث خطأ أثناء فحص الرابط. حاول مجددًا بعد لحظات." }, { status:500 });
  }
}
