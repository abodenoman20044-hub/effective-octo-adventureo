import { NextResponse } from "next/server";
import { db } from "@/db";
import { linkChecks } from "@/db/schema";
import { verifyDownloadToken, resolveFfmpeg, getYtdlpCmd } from "@/lib/downloader";
import { validateUserUrl, rateLimit, getClientIp } from "@/lib/security";
import { execFile } from "child_process";
import { createReadStream, existsSync, statSync, unlinkSync, mkdirSync } from "fs";
import os from "os";
import path from "path";
import crypto from "crypto";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 180;

export async function GET(req: Request) {
  if (!rateLimit(`dl:${getClientIp(req)}`, 12, 60_000)) {
    return NextResponse.json({ ok: false, message: "طلبات تحميل كثيرة. انتظر دقيقة." }, { status: 429 });
  }
  const token = new URL(req.url).searchParams.get("token") || "";
  const payload = verifyDownloadToken(token);
  if (!payload) {
    return NextResponse.json({ ok: false, message: "رابط التحميل منتهٍ أو غير صالح (الصلاحية 15 دقيقة). افحص رابط الفيديو من جديد للحصول على رابط تحميل حديث." }, { status: 403 });
  }

  // ===== MERGED DOWNLOAD: yt-dlp downloads video+audio and ffmpeg merges to one MP4 on server =====
  if (payload.type === "merge" && payload.src && payload.fmt) {
    const srcV = validateUserUrl(payload.src);
    if (!srcV.ok) return NextResponse.json({ ok: false, message: "رابط المصدر غير صالح." }, { status: 400 });
    const ytdlp = getYtdlpCmd(); const ffmpeg = resolveFfmpeg();
    if (!ytdlp || !ffmpeg) return NextResponse.json({ ok: false, message: "محرك الدمج غير متاح على هذا الخادم (yt-dlp/ffmpeg مفقود)." }, { status: 503 });
    try {
      await db.insert(linkChecks).values({ platformKey: payload.p || "unknown", domain: srcV.url.hostname, success: true, status: "download_started", hasPreview: false }).catch(() => {});
      const id = crypto.randomBytes(8).toString("hex");
      const dir = path.join(os.tmpdir(), `aboud-${id}`);
      mkdirSync(dir, { recursive: true });
      const outTpl = path.join(dir, "video.%(ext)s");
      await new Promise<void>((resolve, reject) => {
        execFile(ytdlp.cmd, [...ytdlp.prefix, "-f", payload.fmt!, "--merge-output-format", "mp4", "--ffmpeg-location", ffmpeg, "--no-playlist", "--no-warnings", "--no-check-certificates", "--socket-timeout", "20", "-o", outTpl, srcV.url.toString()],
          { timeout: 150_000, maxBuffer: 10 * 1024 * 1024, windowsHide: true },
          (err: any, _stdout: string, stderr: string) => err ? reject(new Error((stderr || err.message || "merge failed").toString().split("\n").filter(Boolean).slice(-2).join(" ").slice(0, 300))) : resolve());
      });
      const file = path.join(dir, "video.mp4");
      if (!existsSync(file)) throw new Error("لم يتم إنتاج ملف مدمج");
      const size = statSync(file).size;
      const filename = payload.f || "aboud-video.mp4";
      const stream = createReadStream(file);
      stream.on("close", () => { try { unlinkSync(file); } catch {} });
      return new Response(stream as any, {
        status: 200,
        headers: {
          "Content-Disposition": `attachment; filename="aboud-video.mp4"; filename*=UTF-8''${encodeURIComponent(filename)}`,
          "Content-Type": "video/mp4",
          "Content-Length": String(size),
          "Cache-Control": "private, no-store",
          "X-Aboud-Mode": "merged-ffmpeg",
        },
      });
    } catch (e: any) {
      return NextResponse.json({ ok: false, message: `فشل إعداد الملف المدمج على الخادم: ${String(e?.message || e).slice(0, 250)}. جرّب جودة أقل أو افحص الرابط مجددًا.` }, { status: 502 });
    }
  }

  // ===== DIRECT STREAM DOWNLOAD =====
  if (!payload.u) return NextResponse.json({ ok: false, message: "رابط تحميل غير مكتمل." }, { status: 400 });
  const v = validateUserUrl(payload.u);
  if (!v.ok) return NextResponse.json({ ok: false, message: "تم رفض رابط الملف لأسباب أمنية." }, { status: 400 });

  try {
    await db.insert(linkChecks).values({ platformKey: payload.p || "unknown", domain: v.url.hostname, success: true, status: "download_started", hasPreview: false }).catch(() => {});
    const headers: Record<string, string> = { ...(payload.h || {}) };
    const range = req.headers.get("range");
    if (range) headers["Range"] = range;
    if (!headers["User-Agent"]) headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36";
    const upstream = await fetch(v.url.toString(), { headers, redirect: "follow" });
    if (!upstream.ok && upstream.status !== 206) {
      return NextResponse.json({ ok: false, message: `مصدر الملف رفض الطلب (حالة ${upstream.status}). قد انتهت صلاحية رابط المصدر — افحص الفيديو مجددًا.` }, { status: 502 });
    }
    const filename = payload.f || "aboud-video.mp4";
    const resHeaders = new Headers();
    resHeaders.set("Content-Disposition", `attachment; filename="aboud-video.${filename.split(".").pop() || "mp4"}"; filename*=UTF-8''${encodeURIComponent(filename)}`);
    resHeaders.set("Content-Type", upstream.headers.get("content-type") || "application/octet-stream");
    const len = upstream.headers.get("content-length");
    if (len) resHeaders.set("Content-Length", len);
    const cr = upstream.headers.get("content-range");
    if (cr) resHeaders.set("Content-Range", cr);
    resHeaders.set("Accept-Ranges", "bytes");
    resHeaders.set("Cache-Control", "private, no-store");
    resHeaders.set("X-Aboud-Platform", payload.p || "");
    return new Response(upstream.body, { status: upstream.status === 206 ? 206 : 200, headers: resHeaders });
  } catch (e: any) {
    return NextResponse.json({ ok: false, message: "تعذر جلب الملف من المصدر حاليًا. افحص الرابط مجددًا وحاول مرة أخرى." }, { status: 502 });
  }
}
