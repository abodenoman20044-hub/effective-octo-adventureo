import { NextResponse } from "next/server";
import { db } from "@/db";
import { platforms } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
export async function GET(){ await ensureSeeded(); try{ const rows=await db.select().from(platforms).orderBy(platforms.sortOrder); return NextResponse.json({ platforms: rows }); }catch{ return NextResponse.json({ platforms: [] }); } }
