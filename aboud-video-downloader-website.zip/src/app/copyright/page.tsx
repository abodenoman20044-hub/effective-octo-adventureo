import { PageHero } from "@/components/SiteChrome";
import Link from "next/link";
export const metadata={title:"حقوق الملكية الفكرية | عبود"};
export default function Page(){ return <div><PageHero title="حقوق الملكية الفكرية" desc="نحترم حقوق صانعي المحتوى ونلتزم بإجراءات الإزالة السريعة."/><article className="max-w-4xl mx-auto px-4 py-12 bg-white my-10 border rounded-[24px] p-8 leading-8 text-slate-600 space-y-5">
<h2 className="font-black text-xl text-[#071633]">موقفنا</h2><p>جميع الفيديوهات والصور المصغرة والعناوين التي تظهر في المعاينة ملك لأصحابها ومنصاتها الأصلية، وتُجلب لحظيًا من نقاط oEmbed الرسمية دون نسخ أو استضافة على خوادمنا. لا نمنحك أي حق في محتوى لا تملكه.</p>
<h2 className="font-black text-xl text-[#071633]">طلب إزالة / بلاغ انتهاك</h2><p>إذا كنت صاحب حق وتعتقد أن رابطًا يُساء استخدامه عبر موقعنا، أرسل عبر <Link className="text-sky-600 font-bold" href="/contact">صفحة اتصل بنا</Link> ما يلي: (1) رابط المحتوى الأصلي، (2) وصف العمل المحمي، (3) إثبات ملكية أو تفويض، (4) بيانات تواصل صحيحة. سنراجع البلاغات الجادة ونتخذ الإجراء المناسب (تعطيل فحص النطاق/الرابط النمطي عند الاقتضاء) خلال أيام عمل قليلة.</p>
<h2 className="font-black text-xl text-[#071633]">العلامات التجارية</h2><p>YouTube وTikTok وInstagram وFacebook وX وSnapchat وPinterest وReddit وVimeo وTwitch وDailymotion علامات تجارية لأصحابها. ذكرها هنا لغرض وصف التوافق فقط ولا يمثل رعاية أو شراكة.</p>
<h2 className="font-black text-xl text-[#071633]">مسؤولية المستخدم</h2><p>تنزيل أو إعادة نشر محتوى محمي دون إذن قد يعرضك للمساءلة من المنصة الأصلية وصاحب الحق. عند الشك، اطلب إذنًا كتابيًا من صاحب المحتوى أولًا.</p>
</article></div>; }
