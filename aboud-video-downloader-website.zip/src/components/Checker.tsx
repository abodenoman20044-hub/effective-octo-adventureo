"use client";
import { useEffect, useState } from "react";
import { Link2, Search, Loader2, ExternalLink, Download, ShieldCheck, AlertTriangle, CheckCircle2, Play, User, Globe, ClipboardPaste, Eraser, Info, Copy, Check, Zap } from "lucide-react";

type Platform = { id:number; key:string; nameAr:string; nameEn:string; color:string; enabled:boolean; downloadMode:string; oembedSupported:boolean; description:string; domains:string[] };

const EXAMPLES = [
  { label:"مثال يوتيوب", url:"https://www.youtube.com/watch?v=dQw4w9WgXcQ" },
  { label:"مثال فيميو", url:"https://vimeo.com/76979871" },
];

export default function Checker({ platforms }:{ platforms: Platform[] }){
  const [url,setUrl]=useState("");
  const [selected,setSelected]=useState("auto");
  const [loading,setLoading]=useState(false);
  const [result,setResult]=useState<any>(null);
  const [error,setError]=useState("");
  const [copied,setCopied]=useState("");
  const abs=(u?:string|null)=>{ if(!u) return ""; return u.startsWith("http") ? u : `${window.location.origin}${u}`; };
  async function copyText(text:string,key:string){ try{ await navigator.clipboard.writeText(text); }catch{ const ta=document.createElement("textarea"); ta.value=text; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); } setCopied(key); setTimeout(()=>setCopied(""),2200); }

  async function paste(){ try{ const t=await navigator.clipboard.readText(); if(t) setUrl(t); }catch{} }
  async function check(e?:React.FormEvent){
    e?.preventDefault(); setError(""); setResult(null);
    if(!url.trim()){ setError("يرجى لصق رابط الفيديو أولًا."); return; }
    setLoading(true);
    try{
      const r=await fetch("/api/check",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url})});
      const j=await r.json();
      if(!j.ok){ setError(j.message||"تعذر فحص الرابط."); if(j.platform) setResult({ platform:j.platform, originalUrl:j.originalUrl, downloadOptions:[], preview:null, previewAvailable:false, downloadNote:"", disabled:true }); }
      else setResult(j);
    }catch{ setError("تعذر الاتصال بالخادم. تحقق من الإنترنت وحاول مجددًا."); }
    finally{ setLoading(false); }
  }

  const detectedHint = (()=>{ try{ const h=new URL(url).hostname; const p=platforms.find(p=>p.domains?.some((d:string)=>h.includes(d.replace("www.","")))); return p; }catch{ return null; } })();

  return (
    <div id="checker" className="bg-white rounded-[28px] shadow-2xl glow p-5 md:p-7 text-right border border-sky-100">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h2 className="font-black text-[#071633] text-lg flex items-center gap-2"><span className="w-8 h-8 rounded-xl grad-btn grid place-items-center text-white"><Link2 className="w-4 h-4"/></span> فاحص روابط الفيديو</h2>
        <span className="text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full px-3 py-1 flex items-center gap-1"><span className="w-1.5 h-1.5 bg-emerald-500 rounded-full pulse-dot"/> مجاني • بدون تسجيل</span>
      </div>

      <form onSubmit={check} className="mt-5">
        <label className="text-sm font-bold text-slate-700">رابط الفيديو</label>
        <div className="mt-2 flex flex-col md:flex-row gap-2">
          <div className="relative flex-1">
            <input value={url} onChange={e=>setUrl(e.target.value)} dir="ltr" placeholder="https://www.tiktok.com/@user/video/...  الصق الرابط هنا" className="w-full border-2 border-slate-200 rounded-2xl py-4 pl-24 pr-4 text-left text-[15px] bg-slate-50 transition" />
            <div className="absolute left-2 top-1/2 -translate-y-1/2 flex gap-1">
              <button type="button" onClick={paste} className="text-[11px] font-bold bg-white border rounded-lg px-2 py-1.5 flex items-center gap-1 hover:bg-sky-50"><ClipboardPaste className="w-3.5 h-3.5"/> لصق</button>
              {url && <button type="button" onClick={()=>{setUrl("");setResult(null);setError("");}} className="text-[11px] font-bold bg-white border rounded-lg px-2 py-1.5 flex items-center gap-1"><Eraser className="w-3.5 h-3.5"/> مسح</button>}
            </div>
          </div>
          <select value={selected} onChange={e=>setSelected(e.target.value)} className="border-2 border-slate-200 rounded-2xl px-3 py-3 bg-white font-bold text-sm min-w-[170px]">
            <option value="auto">اكتشاف تلقائي للمنصة</option>
            {platforms.map(p=>(<option key={p.key} value={p.key}>{p.nameAr} — {p.nameEn}{!p.enabled?" (معطلة)":""}</option>))}
          </select>
        </div>
        {detectedHint && <p className="text-xs mt-2 font-bold text-sky-700 flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5"/> تم اكتشاف المنصة تلقائيًا: {detectedHint.nameAr} ({detectedHint.nameEn}) — طريقة المعاينة: {detectedHint.oembedSupported?"oEmbed رسمي":"تحقق + فتح أصلي"}</p>}
        <div className="flex flex-wrap gap-2 mt-3">{EXAMPLES.map(ex=>(<button key={ex.label} type="button" onClick={()=>setUrl(ex.url)} className="text-[11px] bg-sky-50 hover:bg-sky-100 text-sky-700 font-bold rounded-full px-3 py-1.5 border border-sky-100">{ex.label}: جرّب الآن</button>))}<span className="text-[11px] text-slate-400 self-center">أو الصق أي رابط عام من المنصات المدعومة</span></div>

        <button disabled={loading} className="grad-btn glow w-full mt-4 text-white font-black text-lg py-4 rounded-2xl flex items-center justify-center gap-2 disabled:opacity-60 transition active:scale-[.99]">
          {loading ? <><Loader2 className="w-5 h-5 animate-spin"/> جارٍ فحص الرابط والتحقق من المنصة…</> : <><Search className="w-5 h-5"/> فحص الرابط</>}
        </button>
        <p className="text-[11px] text-slate-500 text-center mt-3 flex items-center justify-center gap-1"><ShieldCheck className="w-3.5 h-3.5 text-emerald-600"/> لا نخزن رابطك الكامل • حماية SSRF • حدّ طلبات 20/دقيقة • HTTPS فقط</p>
      </form>

      {loading && <div className="mt-5 space-y-3 animate-pulse"><div className="h-4 bg-slate-100 rounded w-3/4"/><div className="flex gap-3"><div className="w-36 h-24 bg-slate-100 rounded-xl"/><div className="flex-1 space-y-2"><div className="h-3 bg-slate-100 rounded"/><div className="h-3 bg-slate-100 rounded w-2/3"/></div></div><p className="text-xs text-slate-500 text-center">جارٍ الفحص + استخراج روابط التحميل المباشر الحقيقية بمحرك yt-dlp على الخادم (قد يستغرق حتى 30 ثانية لبعض المنصات)…</p></div>}

      {error && !result?.platform && <div className="mt-5 bg-red-50 border border-red-200 text-red-800 rounded-2xl p-4 flex gap-3"><AlertTriangle className="w-5 h-5 shrink-0 mt-0.5"/><div><p className="font-black text-sm">تعذر إتمام الفحص</p><p className="text-sm leading-6 mt-1">{error}</p></div></div>}

      {result && (
        <div className="mt-6 border-2 border-sky-100 rounded-[22px] overflow-hidden">
          <div className="bg-[#071633] text-white px-5 py-4 flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-3"><span className="w-10 h-10 rounded-xl grid place-items-center font-black text-white text-sm" style={{background: result.platform?.color||"#2563eb"}}>{(result.platform?.nameEn||"?").slice(0,2).toUpperCase()}</span><div><p className="font-black">{result.platform?.nameAr} — {result.platform?.nameEn}</p><p className="text-[11px] text-sky-300" dir="ltr">{result.domain}</p></div></div>
            <span className={`text-[11px] font-black px-3 py-1 rounded-full ${result.previewAvailable?"bg-emerald-500/20 text-emerald-300 border border-emerald-400/30":"bg-amber-500/20 text-amber-200 border border-amber-400/30"}`}>{result.previewAvailable?"✓ معاينة رسمية متاحة":"تم التحقق من الرابط"}</span>
          </div>
          <div className="p-5">
            {error && <p className="bg-amber-50 border border-amber-200 text-amber-800 text-sm rounded-xl p-3 mb-4">{error}</p>}
            {result.preview ? (
              <div className="flex flex-col sm:flex-row gap-4">
                {result.preview.thumbnail ? <div className="relative shrink-0"><img src={result.preview.thumbnail} alt={result.preview.title||"معاينة الفيديو"} className="w-full sm:w-56 aspect-video object-cover rounded-2xl border"/><span className="absolute inset-0 grid place-items-center"><span className="w-12 h-12 bg-black/55 backdrop-blur rounded-full grid place-items-center text-white"><Play className="w-5 h-5 fill-white"/></span></span></div> : <div className="w-full sm:w-56 aspect-video bg-slate-100 rounded-2xl grid place-items-center text-slate-400"><Play/></div>}
                <div className="flex-1 min-w-0">
                  <h3 className="font-black text-[#071633] leading-7 line-clamp-2">{result.preview.title || "فيديو بدون عنوان ظاهر"}</h3>
                  {result.preview.author && <p className="text-sm text-slate-600 mt-2 flex items-center gap-1"><User className="w-4 h-4"/> {result.preview.author} {result.preview.authorUrl && <a className="text-sky-600 font-bold" href={result.preview.authorUrl} target="_blank" rel="noreferrer">زيارة القناة ↗</a>}</p>}
                  <p className="text-xs text-slate-500 mt-2 flex items-center gap-1"><Globe className="w-3.5 h-3.5"/> المصدر: {result.preview.provider} • نوع المحتوى: {result.preview.type}</p>
                  <p className="text-xs bg-sky-50 text-sky-800 rounded-lg px-3 py-2 mt-3 leading-5">{result.previewNote}</p>
                </div>
              </div>
            ) : (
              <div className="bg-slate-50 rounded-2xl p-4"><p className="font-bold text-sm text-slate-700 flex items-center gap-2"><Info className="w-4 h-4 text-sky-600"/> حالة المعاينة</p><p className="text-sm text-slate-600 leading-7 mt-1">{result.previewNote || "تم التحقق من الرابط بنجاح."}</p></div>
            )}

            {/* Download area — REAL direct downloads + DIRECT LINK panel */}
            <div className="mt-5">
              <div className="flex items-center justify-between flex-wrap gap-2 mb-2"><h4 className="font-black text-sm text-[#071633]">خيارات التحميل المباشر</h4>{result.downloadOptions?.length>0 && <span className="text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-full px-2.5 py-1">● تحميل مباشر حقيقي — استُخرج الآن عبر {result.downloadEngine || "yt-dlp"}</span>}</div>
              {result.downloadOptions && result.downloadOptions.length>0 ? (
                <div>
                  {(()=>{ const best=result.directLink||result.downloadOptions[0]; const proxyAbs=abs(best.downloadUrl||best.url); const raw=best.directUrl as string|null; return (
                    <div className="border-2 border-emerald-300 bg-emerald-50/80 rounded-[20px] p-4 md:p-5 mb-4">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <h5 className="font-black text-emerald-900 flex items-center gap-2"><Zap className="w-5 h-5 text-emerald-600"/> رابط مباشر للتحميل — جاهز الآن</h5>
                        <span className="text-[10px] font-black bg-emerald-600 text-white rounded-full px-2.5 py-1">صالح {best.expiresInMinutes||15} دقيقة فقط</span>
                      </div>
                      <a href={best.downloadUrl||best.url} className="grad-btn glow w-full mt-3 text-white font-black text-base md:text-lg py-4 rounded-2xl flex items-center justify-center gap-2 hover:opacity-95 transition active:scale-[.99]">
                        <Download className="w-6 h-6"/> تحميل مباشر الآن — {best.label}{best.filesizeText?` • ${best.filesizeText}`:""}
                      </a>
                      <label className="block text-xs font-black text-emerald-900 mt-4 mb-1.5">رابط التحميل المباشر من عبود (انسخه أو الصقه في مدير تحميل مثل IDM)</label>
                      <div className="flex gap-2" dir="ltr">
                        <input readOnly value={proxyAbs} onClick={(e:any)=>e.target.select()} className="flex-1 min-w-0 border-2 border-emerald-200 bg-white rounded-xl px-3 py-2.5 text-[11px] text-slate-600 truncate"/>
                        <button type="button" onClick={()=>copyText(proxyAbs,"best")} className={`shrink-0 font-black text-xs px-4 rounded-xl flex items-center gap-1.5 ${copied==="best"?"bg-emerald-600 text-white":"grad-btn text-white"}`}>{copied==="best"?<><Check className="w-4 h-4"/> تم النسخ!</>:<><Copy className="w-4 h-4"/> نسخ الرابط</>}</button>
                      </div>
                      {raw && (<>
                        <label className="block text-xs font-black text-emerald-900 mt-3 mb-1.5">رابط المصدر المباشر (من CDN المنصة نفسها)</label>
                        <div className="flex gap-2" dir="ltr">
                          <input readOnly value={raw} onClick={(e:any)=>e.target.select()} className="flex-1 min-w-0 border-2 border-emerald-200 bg-white rounded-xl px-3 py-2.5 text-[11px] text-slate-600 truncate"/>
                          <button type="button" onClick={()=>copyText(raw,"best-raw")} className={`shrink-0 font-black text-xs px-3 rounded-xl flex items-center gap-1 ${copied==="best-raw"?"bg-emerald-600 text-white":"bg-white border-2 border-emerald-200 text-emerald-800"}`}>{copied==="best-raw"?<><Check className="w-4 h-4"/> تم!</>:<><Copy className="w-4 h-4"/> نسخ</>}</button>
                          <a href={raw} target="_blank" rel="noreferrer" className="shrink-0 font-black text-xs px-3 rounded-xl bg-white border-2 border-emerald-200 text-emerald-800 flex items-center gap-1">فتح ↗</a>
                        </div>
                      </>)}
                      <p className="text-[11px] text-emerald-800 leading-5 mt-2.5">{best.note}</p>
                    </div>
                  ); })()}

                  <p className="text-xs font-black text-slate-600 mb-2">أو اختر جودة أخرى — لكل جودة رابطها المباشر الخاص:</p>
                  <div className="grid sm:grid-cols-2 gap-2.5">{result.downloadOptions.map((d:any,i:number)=>{ const href=d.downloadUrl||d.url; const proxyAbs=abs(href); const kindBadge = d.kind==="merged" ? "⭐ كامل صوت+فيديو — دمج خادم" : d.kind==="av" ? "صوت + فيديو ✓" : d.kind==="video" ? "فيديو فقط — بدون صوت" : "صوت فقط"; const kindCls = (d.kind==="av"||d.kind==="merged") ? "bg-emerald-500/25 text-emerald-100" : d.kind==="video" ? "bg-amber-500/30 text-amber-100" : "bg-sky-500/30 text-sky-100"; return (
                    <div key={i} className="rounded-2xl overflow-hidden border border-sky-100 bg-white shadow-sm">
                      <a href={href} className="grad-btn text-white font-bold px-4 py-3 block hover:opacity-95 transition">
                        <span className="flex items-center justify-between gap-2"><span className="flex items-center gap-2 min-w-0"><Download className="w-5 h-5 shrink-0"/> <span className="truncate">{d.label}</span></span><span className="text-[11px] bg-white/20 rounded px-2 py-0.5 shrink-0 uppercase">{d.ext||"MP4"}</span></span>
                        <span className="flex items-center gap-1.5 mt-2 flex-wrap"><span className={`text-[10px] font-black rounded-full px-2 py-0.5 ${kindCls}`}>{kindBadge}</span>{d.filesizeText && <span className="text-[10px] bg-black/20 rounded-full px-2 py-0.5">{d.filesizeText}</span>}<span className="text-[10px] bg-black/20 rounded-full px-2 py-0.5">رابط صالح {d.expiresInMinutes||15} دقيقة</span></span>
                      </a>
                      <div className="flex flex-wrap gap-1.5 p-2 bg-slate-50">
                        <button type="button" onClick={()=>copyText(proxyAbs,`p-${i}`)} className={`text-[11px] font-black rounded-lg px-2.5 py-1.5 flex items-center gap-1 ${copied===`p-${i}`?"bg-emerald-600 text-white":"bg-white border text-sky-700 hover:bg-sky-50"}`}>{copied===`p-${i}`?<><Check className="w-3.5 h-3.5"/> تم النسخ!</>:<><Copy className="w-3.5 h-3.5"/> نسخ الرابط المباشر</>}</button>
                        {d.directUrl && <><button type="button" onClick={()=>copyText(d.directUrl,`r-${i}`)} className={`text-[11px] font-black rounded-lg px-2.5 py-1.5 flex items-center gap-1 ${copied===`r-${i}`?"bg-emerald-600 text-white":"bg-white border text-slate-600 hover:bg-slate-100"}`}>{copied===`r-${i}`?<><Check className="w-3.5 h-3.5"/> تم!</>:<><Copy className="w-3.5 h-3.5"/> نسخ رابط المصدر</>}</button><a href={d.directUrl} target="_blank" rel="noreferrer" className="text-[11px] font-black rounded-lg px-2.5 py-1.5 bg-white border text-slate-600 flex items-center gap-1">فتح المصدر ↗</a></>}
                        {d.kind==="merged" && <span className="text-[10px] text-slate-400 self-center">الملف الكامل يُبنى عند الضغط على زر التحميل</span>}
                      </div>
                    </div>); })}</div>
                  <p className="text-[11px] text-emerald-700 mt-2 leading-5">{result.downloadNote}</p>
                  <p className="text-[11px] text-slate-500 mt-1 leading-5">💡 «رابط عبود المباشر» يعمل في المتصفح وبرامج إدارة التحميل ويمنحك اسم ملف صحيحًا. «رابط المصدر» هو رابط CDN المنصة الخام وتنتهي صلاحيته بسرعة وقد يحتاج فتحه من نفس الجلسة. اختر صيغ نجمة «كامل صوت+فيديو» لملف MP4 كامل بالصوت. لا نستضيف نسخة دائمة من أي ملف.</p>
                  {result.vidfetchRepo && <p className="text-[11px] text-slate-400 mt-2">محرك التحميل: yt-dlp على خادم عبود • مستودع VidFetch المطلوب ربطه: <a href={result.vidfetchRepo} target="_blank" rel="noreferrer" className="text-sky-600 font-bold" dir="ltr">github.com/achir22hasan1999-crypto/VidFetch</a> (تمت مراجعته — لا يحتوي كود خادم تحميل، انظر الأسئلة الشائعة)</p>}
                </div>
              ) : (
                <div className="border border-dashed border-slate-300 rounded-2xl p-4 bg-white">
                  <p className="text-sm leading-7 text-slate-600">{result.downloadNote}</p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    <a href={result.originalUrl} target="_blank" rel="noreferrer" className="grad-btn text-white font-black px-5 py-3 rounded-xl flex items-center gap-2 text-sm"><ExternalLink className="w-4 h-4"/> فتح الفيديو في المنصة الأصلية</a>
                    <span className="text-[11px] text-slate-400 self-center">هناك قد تجد زر حفظ/تنزيل رسمي من صاحب المحتوى</span>
                  </div>
                </div>
              )}
              <p className="text-[11px] text-slate-400 mt-3">⚖️ {result.disclaimer}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
