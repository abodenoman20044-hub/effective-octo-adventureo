"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Download, Menu, X, ShieldCheck, Zap, Globe, ChevronLeft, Lock } from "lucide-react";

export function Logo({ light=true }:{light?:boolean}){
  return (
    <Link href="/" className="flex items-center gap-3 shrink-0">
      <span className="w-11 h-11 rounded-2xl grad-btn glow-sm grid place-items-center text-white floaty"><Download className="w-6 h-6" strokeWidth={2.6}/></span>
      <span className="leading-tight">
        <span className={`block font-black text-[19px] ${light?"text-white":"text-[#071633]"}`}>عبود <span className="grad-text">لتحميل الفيديوهات</span></span>
        <span className={`block text-[10px] tracking-[.18em] font-bold ${light?"text-sky-300":"text-sky-600"}`}>ABOUD VIDEO DOWNLOADER</span>
      </span>
    </Link>
  );
}

const NAV=[{href:"/",label:"الرئيسية"},{href:"/how-to-use",label:"طريقة الاستخدام"},{href:"/platforms",label:"المنصات المدعومة"},{href:"/faq",label:"الأسئلة الشائعة"},{href:"/contact",label:"اتصل بنا"}];

export function Header(){
  const [open,setOpen]=useState(false); const path=usePathname();
  useEffect(()=>{ fetch("/api/track",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({path})}).catch(()=>{}); },[path]);
  if(path.startsWith("/admin")) return null;
  return (
    <header className="sticky top-0 z-50 bg-[#030b1f]/92 backdrop-blur border-b border-white/10" style={{background:"rgba(3,11,31,.93)"}}>
      <div className="max-w-7xl mx-auto px-4 h-[72px] flex items-center justify-between gap-4">
        <Logo/>
        <nav className="hidden lg:flex items-center gap-1">
          {NAV.map(n=>(<Link key={n.href} href={n.href} className={`px-4 py-2 rounded-full text-[14px] font-bold transition ${path===n.href?"bg-sky-500 text-white glow-sm":"text-slate-200 hover:bg-white/10 hover:text-white"}`}>{n.label}</Link>))}
        </nav>
        <div className="hidden lg:flex items-center gap-2">
          <span className="hidden xl:flex items-center gap-1.5 text-[12px] text-emerald-300 font-bold"><span className="w-2 h-2 rounded-full bg-emerald-400 pulse-dot"/> الخدمة تعمل الآن</span>
          <Link href="/#checker" className="grad-btn text-white font-black text-sm px-5 py-2.5 rounded-full glow-sm">فحص رابط الآن</Link>
        </div>
        <button onClick={()=>setOpen(!open)} className="lg:hidden text-white p-2" aria-label="القائمة">{open?<X/>:<Menu/>}</button>
      </div>
      {open&&(<div className="lg:hidden border-t border-white/10 px-4 py-3 space-y-1 bg-[#030b1f]">{NAV.map(n=>(<Link key={n.href} onClick={()=>setOpen(false)} href={n.href} className="flex items-center justify-between py-3 px-3 rounded-xl text-white font-bold hover:bg-white/10">{n.label}<ChevronLeft className="w-4 h-4 text-sky-400"/></Link>))}<Link href="/#checker" onClick={()=>setOpen(false)} className="block text-center grad-btn text-white font-black py-3 rounded-xl mt-2">فحص رابط الآن</Link></div>)}
    </header>
  );
}

export function AdSlot({label="مساحة إعلانية" }:{label?:string}){
  return <div className="border-2 border-dashed border-sky-200 bg-sky-50/70 rounded-2xl py-5 px-4 text-center"><p className="text-[11px] font-black tracking-widest text-sky-500">{label}</p><p className="text-xs text-slate-500 mt-1">جاهزة للربط بـ Google AdSense أو أي شبكة موثوقة — لا نوافذ منبثقة ولا أزرار وهمية</p></div>;
}

export function Footer(){
  const path=usePathname(); if(path.startsWith("/admin")) return null;
  return (
    <footer className="bg-[#030b1f] text-slate-300 mt-0">
      <div className="max-w-7xl mx-auto px-4 py-12 grid md:grid-cols-4 gap-8">
        <div className="md:col-span-2"><Logo/><p className="text-sm leading-7 mt-4 max-w-md">منصة عربية لفحص روابط الفيديو ومعاينتها من المنصات الرسمية عبر واجهات oEmbed المعتمدة. لا نضع أزرار تنزيل وهمية ولا نتجاوز شروط أي منصة.</p><div className="flex gap-2 mt-4">{[ShieldCheck,Zap,Globe].map((I,i)=>(<span key={i} className="w-9 h-9 rounded-xl bg-white/10 grid place-items-center text-sky-400"><I className="w-4 h-4"/></span>))}<span className="text-xs self-center">آمن • سريع • يحترم حقوق النشر</span></div></div>
        <div><h4 className="text-white font-black mb-3">روابط سريعة</h4><ul className="space-y-2 text-sm">{NAV.map(n=>(<li key={n.href}><Link className="hover:text-sky-300" href={n.href}>{n.label}</Link></li>))}<li><Link className="hover:text-sky-300 flex items-center gap-1" href="/admin/login"><Lock className="w-3 h-3"/> لوحة الإدارة</Link></li></ul></div>
        <div><h4 className="text-white font-black mb-3">قانوني</h4><ul className="space-y-2 text-sm"><li><Link className="hover:text-sky-300" href="/privacy">سياسة الخصوصية</Link></li><li><Link className="hover:text-sky-300" href="/terms">شروط الاستخدام</Link></li><li><Link className="hover:text-sky-300" href="/copyright">حقوق الملكية الفكرية</Link></li><li><a className="hover:text-sky-300" href="https://github.com/achir22hasan1999-crypto/VidFetch" target="_blank" rel="noreferrer">مستودع VidFetch على GitHub ↗</a></li></ul><p className="text-xs leading-5 mt-4 text-slate-400">عند ربط مزود تنزيل مرخّص سيتم تحديث هذه الصفحات تلقائيًا ببياناته.</p></div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs">© {new Date().getFullYear()} عبود لتحميل الفيديوهات — Aboud Video Downloader. جميع الحقوق محفوظة لأصحاب المحتوى الأصلي.</div>
    </footer>
  );
}

export function PageHero({title,desc,badge}:{title:string;desc:string;badge?:string}){
  return <section className="hero-bg text-white"><div className="max-w-7xl mx-auto px-4 py-14 md:py-20 text-center"><span className="inline-block bg-white/10 border border-white/15 rounded-full px-4 py-1.5 text-xs font-bold text-sky-200">{badge||"عبود لتحميل الفيديوهات"}</span><h1 className="text-3xl md:text-5xl font-black mt-5 leading-tight">{title}</h1><p className="text-slate-300 max-w-2xl mx-auto mt-4 leading-8">{desc}</p></div></section>;
}
