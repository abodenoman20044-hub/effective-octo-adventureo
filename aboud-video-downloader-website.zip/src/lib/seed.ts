import { db } from "@/db";
import { platforms, faqs, siteSettings } from "@/db/schema";
import { PLATFORM_DEFS, DEFAULT_FAQS } from "./platforms";
import { eq } from "drizzle-orm";
import { VIDFETCH_REPO } from "./downloader";

let seeded = false;
export async function ensureSeeded() {
  if (seeded) return;
  try {
    const existing = await db.select().from(platforms).limit(1);
    if (existing.length === 0) {
      await db.insert(platforms).values(PLATFORM_DEFS.map((p,i)=>({
        key:p.key, nameAr:p.nameAr, nameEn:p.nameEn, color:p.color, domains:p.domains,
        enabled:true, downloadMode:p.downloadMode, oembedSupported:p.oembedSupported, description:p.description, sortOrder:i+1,
      })));
    }
    const fq = await db.select().from(faqs).limit(1);
    if (fq.length === 0) await db.insert(faqs).values(DEFAULT_FAQS);
    const st = await db.select().from(siteSettings).limit(1);
    if (st.length === 0) {
      await db.insert(siteSettings).values([
        { key:"announcement", value:"أهلًا بك في عبود لتحميل الفيديوهات — افحص أي رابط فيديو واحصل على معاينة فورية مجانًا" },
        { key:"downloader_status", value: process.env.DOWNLOADER_API_URL ? "configured" : "not_configured" },
        { key:"ads_status", value:"غير مفعّلة — مساحات إعلانية جاهزة للربط مستقبلًا دون إزعاج" },
      ]);
    }
    // One-time upgrade v3: direct-link FAQ
    const flag3 = await db.select().from(siteSettings).where(eq(siteSettings.key, "direct_link_v3"));
    if (flag3.length === 0) {
      const all = await db.select().from(faqs).catch(()=>[] as any[]);
      if (!all.some((f:any)=>f.question.includes("الفرق بين زر التحميل والرابط المباشر"))) {
        await db.insert(faqs).values({ question:"ما الفرق بين زر التحميل والرابط المباشر؟ وكيف أنسخ الرابط المباشر؟", answer:"بعد فحص أي فيديو ستجد في الأعلى لوحة خضراء «رابط مباشر للتحميل — جاهز الآن». زر «تحميل مباشر الآن» يبدأ التنزيل فورًا بأفضل جودة كاملة (صوت+فيديو). وتحته «رابط التحميل المباشر من عبود» وهو رابط كامل يمكنك نسخه ولصقه في المتصفح أو في برنامج إدارة تحميل مثل IDM — انسخه من زر «نسخ الرابط». أما «رابط المصدر المباشر» فهو رابط CDN المنصة الخام نفسه وتنتهي صلاحيته بسرعة من المنصة وقد لا يعمل خارج جلسته، لذلك رابط عبود أكثر استقرارًا ويعطيك اسم ملف صحيحًا. جميع الروابط صالحة 15 دقيقة فقط؛ إذا انتهت أعد فحص الفيديو لتحصل على رابط جديد. يوجد أيضًا API للمطورين: POST /api/direct-link يعيد الرابط المباشر فقط بصيغة JSON.", sortOrder:9, published:true }).catch(()=>{});
      }
      await db.insert(siteSettings).values([{ key:"direct_link_v3", value:"done" }]).catch(()=>{});
    }
    // One-time upgrade v2: direct download via yt-dlp + VidFetch repo link
    const flag = await db.select().from(siteSettings).where(eq(siteSettings.key, "ytdlp_upgrade_v2"));
    if (flag.length === 0) {
      for (const p of PLATFORM_DEFS) {
        await db.update(platforms).set({ downloadMode: p.downloadMode, description: p.description }).where(eq(platforms.key, p.key)).catch(()=>{});
      }
      // Refresh FAQs to new truthful set (keep admin-added custom ones by only replacing defaults if count small)
      const allFaqs = await db.select().from(faqs);
      if (allFaqs.length <= 8) {
        await db.delete(faqs).catch(()=>{});
        await db.insert(faqs).values(DEFAULT_FAQS).catch(()=>{});
      } else {
        const has = allFaqs.some(f=>f.question.includes("التحميل المباشر يعمل"));
        if (!has) await db.insert(faqs).values(DEFAULT_FAQS.filter(f=>f.question.includes("التحميل المباشر") || f.question.includes("VidFetch") || f.question.includes("صلاحية"))).catch(()=>{});
      }
      await db.insert(siteSettings).values([
        { key:"ytdlp_upgrade_v2", value:"done" },
        { key:"vidfetch_repo", value:VIDFETCH_REPO },
        { key:"downloader_engine", value:"yt-dlp via youtube-dl-exec (server-side)" },
      ]).catch(()=>{});
    }
    seeded = true;
  } catch (e) { console.error("seed error", e); }
}
export function isAdmin(req: Request): boolean {
  const cookie = req.headers.get("cookie") || "";
  const token = process.env.ADMIN_SESSION_TOKEN || "aboud-admin-session-2026";
  return cookie.includes(`aboud_admin=${token}`);
}
export function adminPassword(): string { return process.env.ADMIN_PASSWORD || "Aboud@2026"; }
