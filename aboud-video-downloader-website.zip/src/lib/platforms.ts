export type PlatformDef = {
  key: string; nameAr: string; nameEn: string; color: string;
  domains: string[]; oembedSupported: boolean; downloadMode: string; description: string;
  oembed?: (url: string) => string;
  example: string;
};

export const PLATFORM_DEFS: PlatformDef[] = [
  { key:"youtube", nameAr:"يوتيوب", nameEn:"YouTube", color:"#FF0000", domains:["youtube.com","youtu.be","m.youtube.com","music.youtube.com"], oembedSupported:true, downloadMode:"direct", description:"معاينة رسمية + تحميل مباشر حقيقي: محرك yt-dlp على خادمنا يستخرج صيغ MP4 (صوت+فيديو) من المصدر ويبثها لك عبر /api/download-file. قد تطلب يوتيوب أحيانًا تأكيدًا ضد الروبوتات من IP الخادم لبعض الفيديوهات فتظهر رسالة صادقة.", example:"https://www.youtube.com/watch?v=...", oembed:(u)=>`https://www.youtube.com/oembed?url=${encodeURIComponent(u)}&format=json` },
  { key:"tiktok", nameAr:"تيك توك", nameEn:"TikTok", color:"#000000", domains:["tiktok.com","vm.tiktok.com","vt.tiktok.com"], oembedSupported:true, downloadMode:"direct", description:"معاينة TikTok oEmbed + استخراج تحميل مباشر عبر yt-dlp للفيديوهات العامة. النتيجة تعتمد على إتاحة الفيديو وقيود المنصة لحظيًا.", example:"https://www.tiktok.com/@user/video/...", oembed:(u)=>`https://www.tiktok.com/oembed?url=${encodeURIComponent(u)}` },
  { key:"vimeo", nameAr:"فيميو", nameEn:"Vimeo", color:"#1AB7EA", domains:["vimeo.com","player.vimeo.com"], oembedSupported:true, downloadMode:"direct", description:"معاينة Vimeo oEmbed + تحميل مباشر عبر yt-dlp للفيديوهات العامة (غالبًا صيغ MP4 كاملة الصوت والصورة).", example:"https://vimeo.com/...", oembed:(u)=>`https://vimeo.com/api/oembed.json?url=${encodeURIComponent(u)}` },
  { key:"twitter", nameAr:"إكس (تويتر)", nameEn:"X (Twitter)", color:"#000000", domains:["twitter.com","x.com","t.co"], oembedSupported:true, downloadMode:"direct", description:"معاينة X oEmbed + استخراج فيديو المنشور عبر yt-dlp عند كونه عامًا. المنشورات المحمية تتطلب المنصة الأصلية.", example:"https://x.com/user/status/...", oembed:(u)=>`https://publish.twitter.com/oembed?url=${encodeURIComponent(u)}` },
  { key:"reddit", nameAr:"ريديت", nameEn:"Reddit", color:"#FF4500", domains:["reddit.com","redd.it","www.reddit.com"], oembedSupported:true, downloadMode:"direct", description:"معاينة Reddit oEmbed + محاولة استخراج فيديو المنشور (v.redd.it) عبر yt-dlp للمنشورات العامة.", example:"https://www.reddit.com/r/.../comments/...", oembed:(u)=>`https://www.reddit.com/oembed?url=${encodeURIComponent(u)}` },
  { key:"instagram", nameAr:"إنستغرام", nameEn:"Instagram", color:"#E1306C", domains:["instagram.com","www.instagram.com","instagr.am"], oembedSupported:false, downloadMode:"direct", description:"محاولة استخراج مباشر عبر yt-dlp للريلز/الفيديوهات العامة. إنستغرام يقيد خوادم كثيرة وقد يتطلب تسجيل دخول — عندها نعرض رسالة صادقة وزر فتح الأصل، ولا نتجاوز الدخول.", example:"https://www.instagram.com/reel/..." },
  { key:"facebook", nameAr:"فيسبوك", nameEn:"Facebook", color:"#1877F2", domains:["facebook.com","www.facebook.com","fb.watch","m.facebook.com"], oembedSupported:false, downloadMode:"direct", description:"محاولة استخراج مباشر عبر yt-dlp للفيديوهات العامة على فيسبوك. المحتوى الخاص أو المقيد يظهر لك برسالة واضحة مع فتح الأصل.", example:"https://www.facebook.com/watch/?v=..." },
  { key:"snapchat", nameAr:"سناب شات", nameEn:"Snapchat", color:"#D9A400", domains:["snapchat.com","www.snapchat.com"], oembedSupported:false, downloadMode:"info_only", description:"سناب شات لا يوفر واجهة oEmbed أو تنزيل عامة للقصص. نتحقق من صحة الرابط ونفتح المحتوى في سناب شات مباشرة.", example:"https://www.snapchat.com/..." },
  { key:"pinterest", nameAr:"بينترست", nameEn:"Pinterest", color:"#E60023", domains:["pinterest.com","pin.it","www.pinterest.com"], oembedSupported:false, downloadMode:"direct", description:"محاولة استخراج فيديو البن العام عبر yt-dlp. عند عدم توفر صيغة مباشرة نوفر فتح المصدر الأصلي داخل Pinterest.", example:"https://www.pinterest.com/pin/..." },
  { key:"dailymotion", nameAr:"ديلي موشن", nameEn:"Dailymotion", color:"#0A0A0A", domains:["dailymotion.com","dai.ly"], oembedSupported:true, downloadMode:"direct", description:"معاينة Dailymotion oEmbed + تحميل مباشر عبر yt-dlp للفيديوهات العامة.", example:"https://www.dailymotion.com/video/...", oembed:(u)=>`https://www.dailymotion.com/services/oembed?url=${encodeURIComponent(u)}&format=json` },
  { key:"twitch", nameAr:"تويتش", nameEn:"Twitch", color:"#9146FF", domains:["twitch.tv","www.twitch.tv","clips.twitch.tv"], oembedSupported:false, downloadMode:"direct", description:"محاولة استخراج مقاطع/فيديوهات Twitch العامة عبر yt-dlp، مع فتح المصدر الأصلي عند تقييد الاستخراج.", example:"https://www.twitch.tv/videos/..." },
];

export function detectPlatform(hostname: string): PlatformDef | null {
  const h = hostname.toLowerCase().replace(/^www\./, "");
  for (const p of PLATFORM_DEFS) {
    if (p.domains.some(d => { const dd=d.replace(/^www\./,""); return h===dd || h.endsWith("."+dd); })) return p;
  }
  return null;
}

export const DEFAULT_FAQS = [
  { question:"هل الموقع مجاني؟", answer:"نعم، فحص الروابط ومعاينة معلومات الفيديو مجاني بالكامل. قد تُضاف مستقبلًا مزايا اختيارية أو إعلانات غير مزعجة لدعم تشغيل الموقع، دون إخفاء زر الفحص أبدًا.", sortOrder:1 },
  { question:"هل التحميل المباشر يعمل الآن فعليًا؟", answer:"نعم. عند فحص رابط عام، يشغّل خادمنا محرك yt-dlp مفتوح المصدر لاستخراج صيغ الملف الحقيقية من مصدر الفيديو، ثم يبث لك الملف عبر /api/download-file برابط موقّع صالح 15 دقيقة. إذا ظهرت لك أزرار بجودات MP4 فهي روابط حقيقية تم استخراجها لحظيًا. إذا فشل الاستخراج لفيديو معين (خاص/محذوف/حماية روبوتات من المنصة) نعرض السبب بصدق ولا نضع زرًا وهميًا.", sortOrder:2 },
  { question:"ما علاقة مستودع VidFetch بالتحميل؟ وكيف يعمل المحرك؟", answer:"رابط المستودع: https://github.com/achir22hasan1999-crypto/VidFetch — تمت مراجعته برمجيًا ووجدنا أن ملفاته ليست كود خادم تحميل (ملفات HTML محفوظة بأسماء .zip)، لذلك لا يمكنه وحده توليد روابط تحميل. التحميل في عبود يعمل فعليًا بمحرك yt-dlp المنصّب على الخادم عبر حزمة youtube-dl-exec. للنشر الاحترافي على خادم دائم (VPS/Docker/Render) سيعمل بنفس الطريقة؛ على استضافات Serverless قد تحتاج ضبط YTDLP_PATH أو خادمًا منفصلًا للمحرك.", sortOrder:3 },
  { question:"هل تحفظون روابطي أو بياناتي؟", answer:"لا. لا نخزن نص الرابط الكامل. نخزن فقط اسم المنصة والنطاق وحالة الفحص لأغراض إحصائية مجهولة وتحسين الخدمة. راجع سياسة الخصوصية للتفاصيل.", sortOrder:4 },
  { question:"هل تنزيل أي فيديو قانوني؟", answer:"تنزيل المحتوى المحمي بحقوق النشر بدون إذن صاحبه قد يكون مخالفًا للقانون وشروط المنصة. استخدم الموقع فقط للمحتوى الذي تملكه أو لديك إذن باستخدامه أو المحتوى المرخص للتنزيل. أنت مسؤول عن استخدامك.", sortOrder:5 },
  { question:"ماذا أفعل إذا ظهرت رسالة (رابط غير مدعوم)؟", answer:"تأكد أن الرابط يبدأ بـ https وأنه من منصة مدعومة وأنه فيديو عام وليس خاصًا. انسخ الرابط مباشرة من زر المشاركة في التطبيق ثم حاول مجددًا. إذا استمرت المشكلة تواصل معنا من صفحة اتصل بنا.", sortOrder:6 },
  { question:"لماذا صلاحية رابط التحميل 15 دقيقة فقط؟", answer:"روابط مصادر الفيديو موقّعة ومؤقتة بطبيعتها من المنصات. نعيد توقيعها عبر خادمنا لمدة 15 دقيقة لحماية الخدمة من إساءة الاستخدام وسرقة النطاق الترددي. إذا انتهت، افحص رابط الفيديو من جديد وستحصل على رابط تحميل حديث فورًا.", sortOrder:8 },
  { question:"هل يعمل الموقع على الهاتف؟", answer:"نعم، التصميم متجاوب بالكامل مع iPhone وAndroid والأجهزة اللوحية والكمبيوتر، ومهيأ للعمل حتى مع اتصال إنترنت بطيء.", sortOrder:7 },
];
