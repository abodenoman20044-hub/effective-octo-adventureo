import { execFile } from "child_process";
import { existsSync } from "fs";
import path from "path";
import crypto from "crypto";

export const VIDFETCH_REPO = "https://github.com/achir22hasan1999-crypto/VidFetch";
export const VIDFETCH_AUDIT = "تمت مراجعة مستودع VidFetch بتاريخ التنفيذ: ملفاته الأربعة ليست كود خادم تحميل — ثلاثة منها صفحات HTML محفوظة بأسماء .zip (صفحة Cookie-check وصفحة YouTube Thumbnail Grabber) والرابع ZIP متداخل يحتوي نفس صفحة HTML. لا يوجد فيه API ولا yt-dlp ولا أي كود استخراج روابط، لذلك لا يمكنه بحد ذاته توليد تحميل مباشر. تم ربط رابطه في الموقع، وتم تنفيذ التحميل فعليًا بمحرك yt-dlp مفتوح المصدر على خادم عبود.";

function secret(): string {
  return process.env.DOWNLOAD_SECRET || process.env.ADMIN_SESSION_TOKEN || "aboud-download-secret-change-me-in-production";
}
function sign(payloadB64: string): string {
  return crypto.createHmac("sha256", secret()).update(payloadB64).digest("base64url");
}
export type DownloadTokenPayload = { u?: string; f: string; p: string; q: string; h?: Record<string, string>; exp: number; type?: string; src?: string; fmt?: string };
export function createDownloadToken(data: { u?: string; f: string; p: string; q: string; h?: Record<string, string>; type?: string; src?: string; fmt?: string }): string {
  const payload = { ...data, exp: Date.now() + 15 * 60 * 1000 };
  const b64 = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${b64}.${sign(b64)}`;
}
export function verifyDownloadToken(token: string): DownloadTokenPayload | null {
  try {
    const [b64, sig] = token.split(".");
    if (!b64 || !sig) return null;
    const expected = sign(b64);
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const payload = JSON.parse(Buffer.from(b64, "base64url").toString("utf8"));
    if (payload.exp < Date.now()) return null;
    if (payload.type === "merge") { if (!payload.src || !payload.fmt) return null; }
    else if (!payload.u) return null;
    return payload;
  } catch { return null; }
}
export function resolveFfmpeg(): string | null {
  const candidates = [process.env.FFMPEG_PATH || "", path.join(process.cwd(), "node_modules", "ffmpeg-static", "ffmpeg"), "/usr/bin/ffmpeg"].filter(Boolean);
  for (const c of candidates) if (existsSync(c)) return c;
  return null;
}
export function getYtdlpCmd(): { cmd: string; prefix: string[] } | null { return resolveYtdlp(); }

function resolveYtdlp(): { cmd: string; prefix: string[] } | null {
  const candidates = [
    process.env.YTDLP_PATH || "",
    path.join(process.cwd(), "node_modules", "youtube-dl-exec", "bin", "yt-dlp"),
    "/tmp/pylibs/bin/yt-dlp",
    "/usr/local/bin/yt-dlp",
  ].filter(Boolean);
  for (const c of candidates) if (existsSync(c)) return { cmd: c, prefix: [] };
  // PATH fallback
  return { cmd: "yt-dlp", prefix: [] };
}

function runYtdlp(url: string): Promise<any> {
  const resolved = resolveYtdlp();
  if (!resolved) return Promise.reject(new Error("yt-dlp binary not found"));
  const args = [
    "-j", "--no-playlist", "--no-warnings", "--no-check-certificates",
    "--socket-timeout", "15", "--extractor-retries", "2", "--no-cache-dir",
    "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
    url,
  ];
  return new Promise((resolve, reject) => {
    execFile(resolved.cmd, [...resolved.prefix, ...args], { timeout: 30_000, maxBuffer: 30 * 1024 * 1024, windowsHide: true }, (err: any, stdout: string, stderr: string) => {
      if (stdout && stdout.trim()) {
        try { resolve(JSON.parse(stdout.trim().split("\n").pop() || "{}")); return; } catch {}
      }
      const msg = (stderr || err?.message || "extraction failed").toString().split("\n").filter(Boolean).slice(-2).join(" ").slice(0, 400);
      reject(new Error(msg || "extraction failed"));
    });
  });
}

function fmtBytes(n?: number | null): string {
  if (!n || isNaN(n)) return "";
  const u = ["B", "KB", "MB", "GB"]; let i = 0; let v = n;
  while (v >= 1024 && i < 3) { v /= 1024; i++; }
  return `${v.toFixed(v >= 100 ? 0 : 1)} ${u[i]}`;
}
function sanitizeFilename(name: string, ext: string): string {
  const clean = (name || "aboud-video").replace(/[\\/:*?"<>|\n\r#]/g, " ").replace(/\s+/g, " ").trim().slice(0, 90) || "aboud-video";
  return `${clean}.${ext || "mp4"}`;
}

export type ExtractResult = {
  ok: boolean; engine: string; title?: string; thumbnail?: string; uploader?: string;
  duration?: number; options: any[]; error?: string; rawFormats?: number;
};

export async function extractDownloadOptions(url: string, platformKey: string, platformName: string): Promise<ExtractResult> {
  const engine = "yt-dlp (محرك استخراج مفتوح المصدر على خادم عبود)";
  try {
    const info: any = await runYtdlp(url);
    const formats: any[] = Array.isArray(info.formats) ? info.formats : [];
    const title: string = info.title || `${platformName} video`;
    // Only true direct-file protocols (exclude HLS/m3u8 manifests & storyboards which are not downloadable files)
    const usable = formats.filter((f: any) => f && typeof f.url === "string" && f.url.startsWith("https://") && f.ext !== "mhtml" && !(f.protocol || "").includes("m3u8") && f.protocol !== "mhtml" && !(f.format_id || "").startsWith("sb"));
    const combined = usable.filter((f: any) => f.vcodec && f.vcodec !== "none" && f.acodec && f.acodec !== "none");
    const videoOnly = usable.filter((f: any) => f.vcodec && f.vcodec !== "none" && (!f.acodec || f.acodec === "none"));
    const audioOnly = usable.filter((f: any) => (!f.vcodec || f.vcodec === "none") && f.acodec && f.acodec !== "none");
    const sortFn = (a: any, b: any) => ((b.height || 0) - (a.height || 0)) || ((b.tbr || 0) - (a.tbr || 0));
    combined.sort(sortFn); videoOnly.sort(sortFn); audioOnly.sort((a: any, b: any) => (b.abr || 0) - (a.abr || 0));

    // MERGED options: server downloads video-only + audio-only and merges with ffmpeg into one complete MP4.
    // This is how real downloaders handle modern YouTube (no progressive formats). Prefer AVC MP4 <=1080p for compatibility & size.
    const mergedOptions: any[] = [];
    const bestAudio = audioOnly.find((f: any) => f.ext === "m4a") || audioOnly[0];
    if (bestAudio && videoOnly.length > 0 && resolveFfmpeg()) {
      const byHeight = new Map<number, any>();
      for (const f of videoOnly) {
        if (!f.height || f.height > 1080) continue;
        const cur = byHeight.get(f.height);
        const score = (f.ext === "mp4" ? 2 : 0) + ((f.vcodec || "").startsWith("avc") ? 1 : 0);
        const curScore = cur ? (cur.ext === "mp4" ? 2 : 0) + ((cur.vcodec || "").startsWith("avc") ? 1 : 0) : -1;
        if (score > curScore) byHeight.set(f.height, f);
      }
      const heights = [...byHeight.keys()].sort((a, b) => b - a).slice(0, 4);
      for (const h of heights) {
        const vf = byHeight.get(h);
        const est = (vf.filesize || vf.filesize_approx || 0) + (bestAudio.filesize || bestAudio.filesize_approx || 0);
        const label = `تحميل كامل ${h}p (صوت+فيديو)`;
        const token = createDownloadToken({ type: "merge", src: url, fmt: `${vf.format_id}+${bestAudio.format_id}`, f: sanitizeFilename(title, "mp4"), p: platformKey, q: label });
        mergedOptions.push({ label, quality: `${h}p`, ext: "mp4", kind: "merged", hasAudio: true, hasVideo: true, height: h, filesize: est || null, filesizeText: fmtBytes(est || null), formatId: `${vf.format_id}+${bestAudio.format_id}`, downloadUrl: `/api/download-file?token=${token}`, directUrl: null, directType: "merged_proxy", directVideoUrl: vf.url || null, expiresInMinutes: 15, note: "يُدمج على الخادم عند الضغط — قد يحتاج 10-60 ثانية حسب الحجم" });
      }
    }

    const picked: any[] = [];
    const seenHeight = new Set<string>();
    for (const f of combined) {
      const key = `${f.height || f.format_note || f.format_id}`;
      if (seenHeight.has(key) && picked.length >= 2) continue;
      seenHeight.add(key); picked.push({ f, kind: "av" });
      if (picked.length >= 6) break;
    }
    if (picked.length === 0 && mergedOptions.length === 0) {
      for (const f of videoOnly.slice(0, 3)) picked.push({ f, kind: "video" });
      for (const f of audioOnly.slice(0, 2)) picked.push({ f, kind: "audio" });
    } else if (picked.length > 0) {
      for (const f of audioOnly.slice(0, 1)) picked.push({ f, kind: "audio" });
    }

    const directOptions = picked.map(({ f, kind }: any) => {
      const ext = (f.ext || "mp4").toLowerCase();
      const quality = kind === "audio" ? ((f.abr && Math.round(f.abr)>0) ? `${Math.round(f.abr)}kbps صوت` : "صوت") : (f.height ? `${f.height}p` : (f.format_note || f.resolution || ""));
      const label = kind === "av" ? `تحميل مباشر ${quality}` : kind === "video" ? `فيديو فقط ${quality} (بدون صوت)` : `صوت فقط ${quality}`;
      const filename = sanitizeFilename(title, ext);
      const token = createDownloadToken({ u: f.url, f: filename, p: platformKey, q: label, h: f.http_headers || {} });
      return {
        label, quality, ext, kind,
        hasAudio: kind !== "video", hasVideo: kind !== "audio",
        height: f.height || null,
        filesize: f.filesize || f.filesize_approx || null,
        filesizeText: fmtBytes(f.filesize || f.filesize_approx),
        formatId: f.format_id || "",
        downloadUrl: `/api/download-file?token=${token}`,
        // REAL direct CDN link extracted from the source — exposed on purpose per user request.
        // It is temporary (platform-signed) and may need the platform headers, so the proxied
        // downloadUrl above stays the most reliable one-click option.
        directUrl: f.url,
        directType: "cdn_direct",
        expiresInMinutes: 15,
      };
    });

    const options = [...mergedOptions, ...directOptions];
    if (options.length === 0) {
      return { ok: false, engine, title, thumbnail: info.thumbnail || "", uploader: info.uploader || "", error: "المحرك وصل للفيديو لكن المنصة لم تُرجع صيغ ملفات قابلة للتحميل المباشر (قد يكون بثًا مباشرًا أو محتوى محميًا).", options: [], rawFormats: formats.length };
    }
    return { ok: true, engine, title, thumbnail: info.thumbnail || "", uploader: info.uploader || info.channel || "", duration: info.duration, options, rawFormats: formats.length };
  } catch (e: any) {
    let msg = String(e?.message || e).slice(0, 400);
    if (/Sign in to confirm|bot/i.test(msg)) msg = "المنصة طلبت تأكيد تسجيل دخول من IP الخادم لهذا الفيديو (حماية ضد الروبوتات). جرّب فيديو آخر أو افتح الأصل.";
    else if (/only works when logged-in|cookies.*to provide|account credentials/i.test(msg)) msg = "المنصة (مثل Vimeo لبعض الفيديوهات) أصبحت تتطلب تسجيل دخول لعرض هذا الفيديو من الخوادم — لا نتجاوز تسجيل الدخول. افتح الفيديو في المنصة الأصلية أو جرّب فيديو عامًا آخر.";
    else if (/Private video|login required|Login required/i.test(msg)) msg = "هذا المحتوى خاص أو يتطلب تسجيل دخول — لا نتجاوز ذلك. افتحه في المنصة الأصلية.";
    else if (/Unsupported URL/i.test(msg)) msg = "المحرك لا يدعم هذا النوع من الروابط داخل المنصة.";
    else if (/Video unavailable|removed|404/i.test(msg)) msg = "الفيديو غير متاح أو محذوف من المنصة الأصلية.";
    return { ok: false, engine, options: [], error: msg };
  }
}
