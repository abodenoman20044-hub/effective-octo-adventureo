const BLOCKED_HOSTS = ["localhost","127.0.0.1","0.0.0.0","::1","169.254.169.254","metadata.google.internal"];
function isPrivateIP(host: string): boolean {
  const m = host.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (!m) return false;
  const [a,b] = [parseInt(m[1]), parseInt(m[2])];
  if (a===10 || a===127 || a===0) return true;
  if (a===172 && b>=16 && b<=31) return true;
  if (a===192 && b===168) return true;
  if (a===169 && b===254) return true;
  return false;
}
export function validateUserUrl(raw: string): { ok:true; url: URL } | { ok:false; error: string } {
  const trimmed = (raw||"").trim();
  if (!trimmed) return { ok:false, error:"يرجى إدخال رابط الفيديو أولًا." };
  if (trimmed.length > 2048) return { ok:false, error:"الرابط طويل جدًا. تأكد من نسخ رابط الفيديو فقط." };
  let url: URL;
  try { url = new URL(trimmed); } catch { return { ok:false, error:"الرابط غير صالح. تأكد أنه يبدأ بـ https:// وأنه منسوخ بالكامل." }; }
  if (url.protocol !== "https:" && url.protocol !== "http:") return { ok:false, error:"يُسمح فقط بروابط http و https الآمنة." };
  if (url.protocol === "http:") url.protocol = "https:";
  if (url.username || url.password) return { ok:false, error:"الرابط يحتوي على بيانات اعتماد مدمجة وهذا غير مسموح لأسباب أمنية." };
  const host = url.hostname.toLowerCase();
  if (BLOCKED_HOSTS.includes(host) || isPrivateIP(host)) return { ok:false, error:"هذا النطاق محظور لأسباب أمنية (SSRF Protection)." };
  if (!host.includes(".")) return { ok:false, error:"اسم النطاق غير صالح." };
  if (/[<>"'`\s]/.test(trimmed)) return { ok:false, error:"الرابط يحتوي على أحرف غير مسموحة." };
  return { ok:true, url };
}

// Simple in-memory rate limiter (per server instance)
const hits = new Map<string, number[]>();
export function rateLimit(key: string, limit = 20, windowMs = 60_000): boolean {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter(t => now - t < windowMs);
  if (arr.length >= limit) { hits.set(key, arr); return false; }
  arr.push(now); hits.set(key, arr); return true;
}
export function getClientIp(req: Request): string {
  const xf = req.headers.get("x-forwarded-for");
  if (xf) return xf.split(",")[0].trim();
  return req.headers.get("x-real-ip") || "unknown";
}
