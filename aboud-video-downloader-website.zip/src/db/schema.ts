import { pgTable, serial, varchar, text, boolean, integer, timestamp, jsonb } from "drizzle-orm/pg-core";

export const platforms = pgTable("platforms", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 50 }).notNull().unique(),
  nameAr: varchar("name_ar", { length: 100 }).notNull(),
  nameEn: varchar("name_en", { length: 100 }).notNull(),
  color: varchar("color", { length: 30 }).notNull().default("#2563eb"),
  domains: jsonb("domains").$type<string[]>().notNull().default([]),
  enabled: boolean("enabled").notNull().default(true),
  downloadMode: varchar("download_mode", { length: 30 }).notNull().default("preview"), // preview | api_ready | info_only
  oembedSupported: boolean("oembed_supported").notNull().default(false),
  description: text("description").notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const faqs = pgTable("faqs", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  subject: varchar("subject", { length: 200 }).notNull().default(""),
  message: text("message").notNull(),
  status: varchar("status", { length: 20 }).notNull().default("new"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const linkChecks = pgTable("link_checks", {
  id: serial("id").primaryKey(),
  platformKey: varchar("platform_key", { length: 50 }).notNull().default("unknown"),
  domain: varchar("domain", { length: 200 }).notNull().default(""),
  success: boolean("success").notNull().default(false),
  status: varchar("status", { length: 40 }).notNull().default("checked"), // ok | invalid | unsupported | disabled | oembed_failed | rate_limited
  hasPreview: boolean("has_preview").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const errorLogs = pgTable("error_logs", {
  id: serial("id").primaryKey(),
  source: varchar("source", { length: 100 }).notNull(),
  message: text("message").notNull(),
  platformKey: varchar("platform_key", { length: 50 }).notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const pageViews = pgTable("page_views", {
  id: serial("id").primaryKey(),
  path: varchar("path", { length: 300 }).notNull().default("/"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const siteSettings = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value").notNull().default(""),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
